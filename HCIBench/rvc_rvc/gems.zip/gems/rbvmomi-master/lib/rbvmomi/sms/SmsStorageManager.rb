# Copyright (c) 2013-2017 VMware, Inc.  All Rights Reserved.
# SPDX-License-Identifier: MIT

class RbVmomi::SMS::SmsStorageManager

  def RegisterProvider_Task2 providerSpec
     self.RegisterProvider_Task providerSpec
  end

end

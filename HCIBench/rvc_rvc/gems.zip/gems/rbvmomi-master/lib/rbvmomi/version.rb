# Copyright (c) 2016-2019 VMware, Inc.  All Rights Reserved.
# SPDX-License-Identifier: MIT

module RbVmomi
  VERSION = '2.4.1'.freeze
end

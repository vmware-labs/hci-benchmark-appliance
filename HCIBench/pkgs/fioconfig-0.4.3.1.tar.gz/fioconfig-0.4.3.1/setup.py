#!/usr/bin/env python3
import codecs
import os

from setuptools import setup, find_packages

here = os.path.abspath(os.path.dirname(__file__))


def read(*parts):
    # intentionally *not* adding an encoding option to open, See:
    #   https://github.com/pypa/virtualenv/issues/201#issuecomment-3145690
    with codecs.open(os.path.join(here, *parts), 'r') as fp:
        return fp.read()


# Read the contents of the README file
long_description = read('README.md')


setup(
    use_scm_version=True,

    name='fioconfig',
    description='Python library to create and manipulate FIO configuration files.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='http://www.vmware.com/',
    license='MIT',
    author='Charles Lee',
    author_email='charlesl@vmware.com',

    package_dir={"": "src"},
    packages=find_packages(
        where="src",
        exclude=["contrib", "docs", "tests*", "tasks"],
    ),

    entry_points={
        "console_scripts": [
            "fioconfig=fioconfig._internal:main"
        ],
    },

    setup_requires=['setuptools_scm'],
    install_requires=[
        "typeguard >= 2.2.2",
        "click >= 7.0",
        "numpy"
    ],

    python_requires='>=3.5'
)
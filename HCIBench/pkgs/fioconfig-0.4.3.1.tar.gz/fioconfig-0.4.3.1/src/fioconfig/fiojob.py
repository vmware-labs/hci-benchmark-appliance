import inspect

from pathlib import Path
from typeguard import typechecked
from typing import Union, List

from fioconfig.fiobssplit import FioBsSplit
from fioconfig.fiocontinueonerror import FioContinueOnError
from fioconfig.fioiogenine import FioIoEngine
from fioconfig.fiopercentagerandom import FioPercentageRandom
from fioconfig.fiorandomgenerator import FioRandomGenerator
from fioconfig.fiorateiops import FioRateIops
from fioconfig.fiorateprocess import FioRateProcess
from fioconfig.fioreadwrite import FioReadWrite
from fioconfig.fiosize import FioSize


class FioJob(object):

    @typechecked
    def __init__(self, name: str, description: str = None):
        """ Instantiate an FIO Job """

        """ 1.12.3. Job description
            Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#job-description
            """
        # ASCII name of the job. This may be used to override the name printed by fio for this job. Otherwise the job
        # name is used. On the command line this parameter has the special purpose of also signaling the start of a
        # new job.
        self.name = name

        # Text description of the job. Does not do anything except dump this text description when this job is run.
        self.description = description

        # Run the specified number of iterations of this job. Used to repeat the same workload a given number of
        # times. Defaults to 1.
        self.loops = None

        # Create the specified number of clones of this job. Each clone of job is spawned as an independent thread or
        # process. May be used to setup a larger number of threads/processes doing the same thing. Each thread is
        # reported separately; to see statistics for all clones as a whole, use group_reporting in conjunction with
        # new_group.
        self.numjobs = None

        """ 1.12.4. Time related parameters
            Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#time-related-parameters
            """
        # Tell fio to terminate processing after the specified period of time. It can be quite hard to determine for
        # how long a specified job will run, so this parameter is handy to cap the total runtime to a given time. When
        # the unit is omitted, the value is interpreted in seconds.
        self.runtime = None

        # If set, fio will run for the duration of the runtime specified even if the file(s) are completely read or
        # written. It will simply loop over the same workload as many times as the runtime allows.
        self.time_based = None

        # If set, fio will run the specified workload for this amount of time before logging any performance numbers.
        # Useful for letting performance settle before logging results, thus minimizing the runtime required for stable
        # results. Note that the ramp_time is considered lead in time for a job, thus it will increase the total
        # runtime if a special timeout or runtime is specified. When the unit is omitted, the value is given in seconds.
        self.ramp_time = None

        """ 1.12.5. Target file/device
            Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#target-file-device   
            """
        # Prefix filenames with this directory. Used to place files in a different location than ./. You can specify a
        # number of directories by separating the names with a ‘:’ character. These directories will be assigned equally
        # distributed to job clones created by numjobs as long as they are using generated filenames. If specific
        # filename(s) are set fio will use the first listed directory, and thereby matching the filename semantic
        # (which generates a file for each clone if not specified, but lets all clones use the same file if set).
        self.directory = None

        # Fio normally makes up a filename based on the job name, thread number, and file number (see filename_format).
        # If you want to share files between threads in a job or several jobs with fixed file paths, specify a filename
        # for each of them to override the default. If the ioengine is file based, you can specify a number of files by
        # separating the names with a ‘:’ colon. So if you wanted a job to open /dev/sda and /dev/sdb as the two working
        # files, you would use filename=/dev/sda:/dev/sdb. This also means that whenever this option is specified,
        # nrfiles is ignored. The size of regular files specified by this option will be size divided by number of files
        # unless an explicit size is specified by filesize.
        self.filename = None

        """ 1.12.6. I/O type
            Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#i-o-type
            """
        # If value is true, use non-buffered I/O. This is usually O_DIRECT.
        # Note that OpenBSD and ZFS on Solaris don’t support direct I/O. On Windows the synchronous ioengines don’t
        # support direct I/O. Default: false.
        self.direct = None

        #
        # If value is true, use buffered I/O. This is the opposite of the direct option. Defaults to true.
        self.buffered = None

        # Fio defaults to read if the option is not specified. For the mixed I/O types, the default is to split them
        # 50/50. For certain types of I/O the result may still be skewed a bit, since the speed may be different.
        #
        # It is possible to specify the number of I/Os to do before getting a new offset by appending :<nr> to the end
        # of the string given. For a random read, it would look like rw=randread:8 for passing in an offset modifier
        # with a value of 8. If the suffix is used with a sequential I/O pattern, then the <nr> value specified will be
        # added to the generated offset for each I/O turning sequential I/O into sequential I/O with holes.
        # For instance, using rw=write:4k will skip 4k for every write. Also see the rw_sequencer option.
        self.readwrite = None

        # If writing to a file, issue an fsync(2) (or its equivalent) of the dirty data for every number of blocks
        # given. For example, if you give 32 as a parameter, fio will sync the file after every 32 writes issued. If
        # fio is using non-buffered I/O, we may not sync the file. The exception is the sg I/O engine, which
        # synchronizes the disk cache anyway. Defaults to 0, which means fio does not periodically issue and wait for
        # a sync to complete. Also see end_fsync and fsync_on_close.
        self.fsync = None

        # Percentage of a mixed workload that should be reads. Default: 50.
        self.rwmixread = None

        # For a random workload, set how big a percentage should be random. This defaults to 100%, in which case the
        # workload is fully random. It can be set from anywhere from 0 to 100. Setting it to 0 would make the workload
        # fully sequential. Any setting in between will result in a random mix of sequential and random I/O, at the
        # given percentages. Comma-separated values may be specified for reads, writes, and trims as described in
        # blocksize.
        self.percentage_random = None

        # Normally fio will cover every block of the file when doing random I/O. If this option is given, fio will
        # just get a new random offset without looking at past I/O history. This means that some blocks may not be
        # read or written, and that some blocks may be read/written more than once. If this option is used with verify
        # and multiple blocksizes (via bsrange), only intact blocks are verified, i.e., partially-overwritten blocks
        # are ignored. With an async I/O engine and an I/O depth > 1, it is possible for the same block to be
        # overwritten, which can cause verification errors. Either do not use norandommap in this case, or also use
        # the lfsr random generator.
        self.norandommap = None

        # Fio supports the following engines for generating I/O offsets for random I/O:
        # - tausworthe:   Strong 2^88 cycle random number generator.
        # - lfsr:         Linear feedback shift register generator.
        # - tausworthe64: Strong 64-bit 2^258 cycle random number generator.
        self.random_generator = None

        """ 1.12.7. Block size
            Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#block-size
            """
        # The block size in bytes used for I/O units. Default: 4096. A single value applies to reads, writes, and trims.
        # Comma-separated values may be specified for reads, writes, and trims. A value not terminated in a comma
        # applies to subsequent types.
        # Note. Alias bs
        self.blocksize = None

        # Sometimes you want even finer grained control of the block sizes issued, not just an even split between them.
        # This option allows you to weight various block sizes, so that you are able to define a specific amount of
        # block sizes issued.
        self.bssplit = None

        # For a random workload, set how big a percentage should be random. This defaults to 100%, in which case the
        # workload is fully random. It can be set from anywhere from 0 to 100. Setting it to 0 would make the workload
        # fully sequential. Any setting in between will result in a random mix of sequential and random I/O, at the
        # given percentages. Comma-separated values may be specified for reads, writes, and trims as described
        # in blocksize.
        self.iodepth_batch = None

        """ 1.12.8. Buffers and memory
            Ref.    
            """

        # If this is set, then fio will attempt to provide I/O buffer content (on WRITEs) that compresses to the
        # specified level. Fio does this by providing a mix of random data followed by fixed pattern data. The fixed
        # pattern is either zeros, or the pattern specified by buffer_pattern. If the buffer_pattern option is used,
        # it might skew the compression ratio slightly. Setting buffer_compress_percentage to a value other than 100
        # will also enable refill_buffers in order to reduce the likelihood that adjacent blocks are so similar that
        # they over compress when seen together. See buffer_compress_chunk for how to set a finer or coarser
        # granularity for the random/fixed data region. Defaults to unset i.e., buffer data will not adhere to any
        # compression level.
        self.buffer_compress_percentage = None

        # f set, fio will generate this percentage of identical buffers when writing. These buffers will be naturally
        # dedupable. The contents of the buffers depend on what other buffer compression settings have been set. It’s
        # possible to have the individual buffers either fully compressible, or not at all – this option only
        # controls the distribution of unique buffers. Setting this option will also enable refill_buffers to prevent
        # every buffer being identical.
        self.dedupe_percentage = None

        """ 1.12.9. I/O size
            Ref.    
            """
        self.size = None

        """ 1.12.10. I/O engine
            Ref.
            """
        self.ioengine = None

        """ 1.12.11. I/O engine specific parameters
            Ref.    
            """
        # Attempt to use the specified percentage of CPU cycles. This is a mandatory option when using cpuio
        # I/O engine.
        self.cpuload = None

        # Split the load into cycles of the given time. In microseconds.
        self.cpuchunks = None

        """ 1.12.12. I/O depth
            Ref.    
            """
        # Number of I/O units to keep in flight against the file. Note that increasing iodepth beyond 1 will not
        # affect synchronous ioengines (except for small degrees when verify_async is in use). Even async engines
        # may impose OS restrictions causing the desired depth not to be achieved. This may happen on Linux when using
        # libaio and not setting direct=1, since buffered I/O is not async on that OS. Keep an eye on the I/O depth
        # distribution in the fio output to verify that the achieved depth is as expected. Default: 1.
        self.iodepth = None

        # This defines how many pieces of I/O to submit at once. It defaults to 1 which means that we submit each I/O
        # as soon as it is available, but can be raised to submit bigger batches of I/O at the time. If it is set to 0
        # the iodepth value will be used.
        self.iodepth_batch = None

        """ 1.12.13. I/O rate
            Ref. https://fio.readthedocs.io/en/latest/fio_doc.html#i-o-rate
            """
        # This option controls how fio manages rated I/O submissions. The default is linear, which submits I/O in a
        # linear fashion with fixed delays between I/Os that gets adjusted based on I/O completion rates. If this is
        # set to poisson, fio will submit I/O based on a more real world random request flow, known as the Poisson
        # process (https://en.wikipedia.org/wiki/Poisson_point_process). The lambda will be 10^6 / IOPS for the given
        # workload.
        self.rate_process = None

        # Cap the bandwidth to this number of IOPS. Basically the same as rate, just specified independently of
        # bandwidth. If the job is given a block size range instead of a fixed value, the smallest block size is used
        # as the metric. Comma-separated values may be specified for reads, writes, and trims as described in blocksize.
        self.rate_iops = None

        """ 1.12.14. I/O latency
            Ref. https://fio.readthedocs.io/en/latest/fio_doc.html#i-o-rate
            """
        # If set, fio will attempt to find the max performance point that the given workload will run at while
        # maintaining a latency below this target. When the unit is omitted, the value is interpreted in microseconds.
        # See latency_window and latency_percentile.
        self.latency_target = None

        # Used with latency_target to specify the sample window that the job is run at varying queue depths to test
        # the performance. When the unit is omitted, the value is interpreted in microseconds.
        self.latency_window = None

        # The percentage of I/Os that must fall within the criteria specified by latency_target and latency_window.
        # If not set, this defaults to 100.0, meaning that all I/Os must be equal or below to the value set by
        # latency_target.
        self.latency_percentile = None

        # Used with latency_target. If false (default), fio will find the highest queue depth that meets latency_
        # target and exit. If true, fio will continue running and try to meet latency_target by adjusting queue depth.
        self.latency_run = None

        """ 1.12.15. I/O replay
            Ref. https://fio.readthedocs.io/en/latest/fio_doc.html#i-o-rate
            """

        """ 1.12.16. Threads, processes and job synchronization
            Ref. https://fio.readthedocs.io/en/latest/fio_doc.html#i-o-rate
            """

        """ 1.12.17. Verification
            Ref. https://fio.readthedocs.io/en/latest/fio_doc.html#i-o-rate
            """

        """ 1.12.18. Steady state 
            Ref. https://fio.readthedocs.io/en/latest/fio_doc.html#steady-state
            """

        """ 1.12.19. Measurements and reporting 
            Ref. https://fio.readthedocs.io/en/latest/fio_doc.html#measurements-and-reporting
            """
        # It may sometimes be interesting to display statistics for groups of jobs as a whole instead of for each
        # individual job. This is especially true if numjobs is used; looking at individual thread/process output
        # quickly becomes unwieldy. To see the final report per-group instead of per-job, use group_reporting. Jobs
        # in a file will be part of the same reporting group, unless if separated by a stonewall, or by using new_group.
        self.group_reporting = None

        # By default, fio will log an entry in the iops, latency, or bw log for every I/O that completes. When writing
        # to the disk log, that can quickly grow to a very large size. Setting this option makes fio average the each
        # log entry over the specified period of time, reducing the resolution of the log. See log_max_value as well.
        # Defaults to 0, logging all entries. Also see Log File Formats.
        self.log_avg_msec = None

        # Generate disk utilization statistics, if the platform supports it. Default: true.
        self.disk_util = None

        # Report submission latency percentiles. Submission latency is not recorded for synchronous ioengines.
        self.slat_percentiles = None

        # Report completion latency percentiles.
        self.clat_percentiles = None

        # Report total latency percentiles. Total latency is the sum of submission latency and completion latency.
        self.lat_percentiles = None

        """ 1.12.20. Error handling
            Ref. https://fio.readthedocs.io/en/latest/fio_doc.html#error-handling
            """

        # Normally fio will exit the job on the first observed failure.
        # If this option is set, fio will continue the job when there is a ‘non-fatal error’ (EIO or EILSEQ) until the
        # runtime is exceeded or the I/O size specified is completed. If this option is used, there are two more stats
        # that are appended, the total error count and the first error. The error field given in the stats is the first
        # error that was hit during the run.
        self.continue_on_error = None

    #
    # Properties
    #

    #
    # 1.12.3. Job description
    #

    # name
    @property
    def name(self) -> str:
        return self._name

    @name.setter
    @typechecked()
    def name(self, value: str):
        self._name = value

    # description
    @property
    def description(self) -> Union[str, None]:
        return self._description

    @description.setter
    @typechecked()
    def description(self, value: Union[str, None]):
        self._description = value

    # loops
    @property
    def loops(self) -> Union[int, None]:
        return self._loops

    @loops.setter
    @typechecked()
    def loops(self, value: Union[int, None]):
        if isinstance(value, int):
            if value < 1:
                raise ValueError('Cannot set {self.__class__.__name__} property ' +
                                 '%s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                 'Received: %s ' % str(value) +
                                 'Expected Min: 1')
        self._loops = value

    # numjobs
    @property
    def numjobs(self) -> Union[int, None]:
        return self._numjobs

    @numjobs.setter
    @typechecked()
    def numjobs(self, value: Union[int, None]):
        if isinstance(value, int):
            if value < 1:
                raise ValueError('Cannot set {self.__class__.__name__} property ' +
                                 '%s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                 'Received: %s ' % str(value) +
                                 'Expected Min: 1')
        self._numjobs = value

    #
    # 1.12.4. Time related parameters
    #

    # runtime
    @property
    def runtime(self) -> Union[int, None]:
        return self._runtime

    @runtime.setter
    @typechecked()
    def runtime(self, value: Union[int, None]):
        if isinstance(value, int):
            if value < 1:
                raise ValueError('Cannot set {self.__class__.__name__} property ' +
                                 '%s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                 'Received: %s ' % str(value) +
                                 'Expected Min: 1')
        self._runtime = value

    # time_based
    @property
    def time_based(self) -> Union[bool, None]:
        return self._time_based

    @time_based.setter
    @typechecked()
    def time_based(self, value: Union[bool, None]):
        self._time_based = value

    # ramp_time
    @property
    def ramp_time(self) -> Union[int, None]:
        return self._ramp_time

    @ramp_time.setter
    @typechecked()
    def ramp_time(self, value: Union[int, None]):
        if isinstance(value, int):
            if value < 1:
                raise ValueError('Cannot set {self.__class__.__name__} property ' +
                                 '%s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                 'Received: %s ' % str(value) +
                                 'Expected Min: 1')
        self._ramp_time = value

    #
    # 1.12.5. Target file/device
    #

    # directory
    @property
    def directory(self) -> Union[Path, None]:
        return self._directory

    @directory.setter
    @typechecked()
    def directory(self, value: Union[Path, None]):
        self._directory = value

    # filename
    @property
    def filename(self) -> Union[List[Path], None]:
        return self._filename

    @filename.setter
    @typechecked()
    def filename(self, value: Union[List[Path], None]):
        self._filename = value

    #
    # 1.12.6. I/O type
    #

    # direct
    @property
    def direct(self) -> Union[bool, None]:
        return self._direct

    @direct.setter
    @typechecked()
    def direct(self, value: Union[bool, None]):
        self._direct = value

    # buffered
    @property
    def buffered(self) -> Union[bool, None]:
        return self._buffered

    @buffered.setter
    @typechecked()
    def buffered(self, value: Union[bool, None]):
        self._buffered = value

    # readwrite
    @property
    def readwrite(self) -> Union[FioReadWrite, None]:
        return self._readwrite

    @readwrite.setter
    @typechecked()
    def readwrite(self, value: Union[FioReadWrite, None]):
        self._readwrite = value

    # fsync
    @property
    def fsync(self) -> Union[int, None]:
        return self._fsync

    @fsync.setter
    @typechecked()
    def fsync(self, value: Union[int, None]):
        self._fsync = value

    # rwmixread
    @property
    def rwmixread(self) -> Union[int, None]:
        return self._rwmixread

    @rwmixread.setter
    @typechecked()
    def rwmixread(self, value: Union[int, None]):
        if isinstance(value, int):
            if value < 0 or value > 100:
                raise ValueError('Cannot set {self.__class__.__name__} property ' +
                                 '%s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                 'Received: %s ' % str(value) +
                                 'Expected Range: [0-100]')
        self._rwmixread = value

    # percentage_random
    @property
    def percentage_random(self) -> Union[FioPercentageRandom, None]:
        return self._percentage_random

    @percentage_random.setter
    @typechecked()
    def percentage_random(self, value: Union[FioPercentageRandom, None]):
        self._percentage_random = value

    # norandommap
    @property
    def norandommap(self) -> Union[bool, None]:
        return self._norandommap

    @norandommap.setter
    @typechecked()
    def norandommap(self, value: Union[bool, None]):
        self._norandommap = value

    # random_generator
    @property
    def random_generator(self) -> Union[FioRandomGenerator, None]:
        return self._random_generator

    @random_generator.setter
    @typechecked()
    def random_generator(self, value: Union[FioRandomGenerator, None]):
        self._random_generator = value

    #
    # Properties 1.12.7. Block size
    #
    @property
    def bssplit(self) -> Union[FioBsSplit, None]:
        return self._bssplit

    @bssplit.setter
    @typechecked()
    def bssplit(self, value: Union[FioBsSplit, None]):
        self._bssplit = value

    #
    # Properties 1.12.8. Buffers and memory
    #
    @property
    def buffer_compress_percentage(self) -> int:
        return self._buffer_compress_percentage

    @buffer_compress_percentage.setter
    @typechecked()
    def buffer_compress_percentage(self, value: Union[int, None]):
        self._buffer_compress_percentage = value

    @property
    def dedupe_percentage(self) -> int:
        return self._dedupe_percentage

    @dedupe_percentage.setter
    @typechecked()
    def dedupe_percentage(self, value: Union[int, None]):
        self._dedupe_percentage = value

    #
    # Properties 1.12.9. I/O size
    #

    # size
    @property
    def size(self) -> Union[FioSize, None]:
        return self._size

    @size.setter
    @typechecked()
    def size(self, value: Union[FioSize, None]):
        self._size = value

    #
    # Properties 1.12.10. I/O engine
    #

    # ioengine
    @property
    def ioengine(self) -> Union[FioIoEngine, None]:
        return self._ioengine

    @ioengine.setter
    @typechecked()
    def ioengine(self, value: Union[FioIoEngine, None]):
        self._ioengine = value

    #
    # Properties 1.12.11. I/O engine specific parameters
    #

    # cpuload
    @property
    def cpuload(self) -> Union[int, None]:
        return self._cpuload

    @cpuload.setter
    @typechecked()
    def cpuload(self, value: Union[int, None]):
        if value is not None and (value < 0 or value > 100):
            raise ValueError('cpuload must be in range 0 - 100')
        self._cpuload = value

    # cpuchunks
    @property
    def cpuchunks(self) -> Union[int, None]:
        return self._cpuchunks

    @cpuchunks.setter
    @typechecked()
    def cpuchunks(self, value: Union[int, None]):
        if value is not None and value < 1:
            raise ValueError('cpuchunks must be greater than 0')
        self._cpuchunks = value

    #
    # 1.12.12. I/O depth
    #

    # iodepth
    @property
    def iodepth(self) -> Union[int, None]:
        return self._iodepth

    @iodepth.setter
    @typechecked()
    def iodepth(self, value: Union[int, None]):
        self._iodepth = value

    # iodepth_batch
    @property
    def iodepth_batch(self) -> Union[int, None]:
        return self._iodepth_batch

    @iodepth_batch.setter
    @typechecked()
    def iodepth_batch(self, value: Union[int, None]):
        self._iodepth_batch = value

    #
    # Properties 1.12.13. I/O rate
    #

    # rate_process
    @property
    def rate_process(self) -> Union[FioRateProcess, None]:
        return self._rate_process

    @rate_process.setter
    @typechecked()
    def rate_process(self, value: Union[FioRateProcess, None]):
        self._rate_process = value

    # rate_iops
    @property
    def rate_iops(self) -> Union[FioRateIops, None]:
        return self._rate_iops

    @rate_iops.setter
    @typechecked()
    def rate_iops(self, value: Union[FioRateIops, None]):
        self._rate_iops = value

    #
    # Properties 1.12.14. I/O latency
    #
    @property
    def latency_target(self) -> Union[int, None]:
        return self._latency_target

    @latency_target.setter
    @typechecked()
    def latency_target(self, value: Union[int, None]):
        self._latency_target = value

    @property
    def latency_window(self) -> Union[int, None]:
        return self._latency_window

    @latency_window.setter
    @typechecked()
    def latency_window(self, value: Union[int, None]):
        self._latency_window = value

    @property
    def latency_percentile(self) -> Union[float, None]:
        return self._latency_percentile

    @latency_percentile.setter
    @typechecked()
    def latency_percentile(self, value: Union[float, None]):
        self._latency_percentile = value

    @property
    def latency_run(self) -> Union[int, None]:
        return self._latency_run

    @latency_run.setter
    @typechecked()
    def latency_run(self, value: Union[int, None]):
        self._latency_run = value

    #
    # Properties 1.12.19. Measurements and reporting
    #

    # group_reporting
    @property
    def group_reporting(self) -> Union[bool, None]:
        return self._group_reporting

    @group_reporting.setter
    @typechecked()
    def group_reporting(self, value: Union[bool, None]):
        self._group_reporting = value

    # log_avg_msec
    @property
    def log_avg_msec(self) -> Union[int, None]:
        return self._log_avg_msec

    @log_avg_msec.setter
    @typechecked()
    def log_avg_msec(self, value: Union[int, None]):
        if isinstance(value, int):
            if value < 0:
                raise ValueError('Cannot set {self.__class__.__name__} property ' +
                                 '%s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                 'Received: %s ' % str(value) +
                                 'Expected Min: 0')
        self._log_avg_msec = value

    # disk_util
    @property
    def disk_util(self) -> Union[bool, None]:
        return self._disk_util

    @disk_util.setter
    @typechecked()
    def disk_util(self, value: Union[bool, None]):
        self._disk_util = value

    # slat_percentiles
    @property
    def slat_percentiles(self) -> Union[bool, None]:
        return self._slat_percentiles

    @slat_percentiles.setter
    @typechecked()
    def slat_percentiles(self, value: Union[bool, None]):
        self._slat_percentiles = value

    # clat_percentiles
    @property
    def clat_percentiles(self) -> Union[bool, None]:
        return self._clat_percentiles

    @clat_percentiles.setter
    @typechecked()
    def clat_percentiles(self, value: Union[bool, None]):
        self._clat_percentiles = value

    # lat_percentiles
    @property
    def lat_percentiles(self) -> Union[bool, None]:
        return self._lat_percentiles

    @lat_percentiles.setter
    @typechecked()
    def lat_percentiles(self, value: Union[bool, None]):
        self._lat_percentiles = value

    #
    # Properties 1.12.20. Error handling
    #

    # continue_on_error
    @property
    def continue_on_error(self) -> Union[FioContinueOnError, None]:
        return self._continue_on_error

    @continue_on_error.setter
    @typechecked()
    def continue_on_error(self, value: Union[FioContinueOnError, None]):
        self._continue_on_error = value

    #
    # I/O
    #
    def __str__(self):

        # 1.12.3. Job description
        value = '[%s]\n' % self.name

        if self.description:
            value += 'description=%s\n' % self.description

        if self.loops:
            value += 'loops=%d\n' % self.loops

        if self.numjobs:
            value += 'numjobs=%d\n' % self.numjobs

        # 1.12.4. Time related parameters
        if self.runtime:
            value += 'runtime=%d\n' % self.runtime

        if self.time_based:
            value += 'time_based=1\n'

        if self.ramp_time is not None:
            value += 'ramp_time=%d\n' % self.ramp_time

        # 1.12.5. Target file/device
        if self.directory:
            value += 'directory=%s\n' % self.directory

        if self.filename:
            value += 'filename=%s\n' % ':'.join([str(x) for x in self.filename])

        # 1.12.6. I/O type
        if self.direct:
            # boolean, but represented as 0/1
            value += 'direct=%d\n' % int(self.direct)

        if self.buffered is not None:
            # boolean, but represented as 0/1
            value += 'buffered=%d\n' % int(self.buffered)

        if self.fsync is not None:
            value += 'fsync=%d\n' % self.fsync

        if self.readwrite:
            value += 'readwrite=%s\n' % self.readwrite

        if self.rwmixread is not None:
            value += 'rwmixread=%d\n' % self.rwmixread

        if self.percentage_random:
            value += 'percentage_random=%s\n' % self.percentage_random

        if self.norandommap:
            value += 'norandommap\n'

        if self.random_generator is not None:
            value += 'random_generator=%s\n' % str(self.random_generator)

        # 1.12.7. Block size
        if self.blocksize is not None:
            value += 'blocksize=%s\n' % self.blocksize

        if self.bssplit is not None:
            value += 'bssplit=%s\n' % self.bssplit

        # 1.12.8
        if self.buffer_compress_percentage is not None:
            value += 'buffer_compress_percentage=%s\n' % self.buffer_compress_percentage

        if self.dedupe_percentage is not None:
            value += 'dedupe_percentage=%s\n' % self.dedupe_percentage

        # 1.12.9 I/O size
        if self.size:
            value += 'size=%s\n' % self.size

        # 1.12.10. I/O engine
        if self.ioengine:
            value += 'ioengine=%s\n' % str(self.ioengine)

        # 1.12.11. cpuload
        if self.cpuload:
            value += 'cpuload=%s\n' % str(self.cpuload)

        # 1.12.11. cpuchunks
        if self.cpuchunks:
            value += 'cpuchunks=%s\n' % str(self.cpuchunks)

        # 1.12.12. I/O depth
        if self.iodepth is not None:
            value += 'iodepth=%d\n' % self.iodepth

        if self.iodepth_batch:
            value += 'iodepth_batch=%s\n' % self.iodepth_batch

        # 1.12.13. I/O rate
        if self.rate_process:
            value += 'rate_process=%s\n' % self.rate_process

        if self.rate_iops:
            value += 'rate_iops=%s\n' % self.rate_iops

        # 1.12.14. I/O latency
        if self.latency_target is not None:
            value += 'latency_target=%s\n' % self.latency_target

        if self.latency_window is not None:
            value += 'latency_window=%s\n' % self.latency_window

        if self.latency_percentile is not None:
            value += 'latency_percentile=%s\n' % self.latency_percentile

        if self.latency_run is not None:
            value += 'latency_run=%s\n' % self.latency_run

        #  1.12.19. Measurements and reporting
        if self.group_reporting:
            value += 'group_reporting\n'

        if self.log_avg_msec:
            value += 'log_avg_msec=%d\n' % self.log_avg_msec

        if self.disk_util is not None:
            value += 'disk_util=%d\n' % int(self.disk_util)

        if self.slat_percentiles is not None:
            value += 'slat_percentiles=%d\n' % int(self.slat_percentiles)

        if self.clat_percentiles is not None:
            value += 'disk_util=%d\n' % int(self.clat_percentiles)

        if self.lat_percentiles is not None:
            value += 'lat_percentiles=%d\n' % int(self.lat_percentiles)

        # 1.12.20. Error handling
        if self.continue_on_error:
            value += 'continue_on_error=%s\n' % self.continue_on_error

        return value


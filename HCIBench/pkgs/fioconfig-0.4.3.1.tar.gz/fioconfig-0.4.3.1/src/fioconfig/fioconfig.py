import string

from pathlib import Path
from typeguard import typechecked

from fioconfig.fiocontinueonerror import FioContinueOnError
from fioconfig.fioiogenine import FioIoEngine
from fioconfig.fiojob import FioJob
from fioconfig.fiopercentagerandom import FioPercentageRandom
from fioconfig.fiorandomgenerator import FioRandomGenerator
from fioconfig.fiorateiops import FioRateIops
from fioconfig.fioreadwrite import FioReadWrite
from fioconfig.fiosize import FioSize


class FioConfig(object):

    @staticmethod
    def __sd_devices(count: int):
        first = [''] + list(string.ascii_lowercase)
        second = list(string.ascii_lowercase)
        return ['/dev/sd%s' % dev for _, dev in zip(range(count), ['%s%s' % (f, s) for f in first for s in second])]

    def __init__(self,
                 block_size: str,
                 testing_time: int,
                 nb_disks: int,
                 read_percentage: int,
                 seek_percentage,
                 working_set: int,
                 warmup_time: int,
                 io_rate: int,
                 nb_threads: int,
                 nb_jobs: int,
                 cpu_load: int = None,
                 nb_cpu: int = None,
                 latency_target: int = None,
                 latency_window: int = None,
                 latency_percentile: float = None,
                 latency_run: int = None,
                 buffer_compress_percentage: int = None,
                 dedupe_percentage: int = None
                 ):

        """
        Ref:    https://github.com/axboe/fio/blob/master/HOWTO

        :param block_size:
        :param testing_time:
        :param nb_disks:
        :param read_percentage:
        :param seek_percentage:
        :param working_set:
        :param warmup_time:
        :param io_rate:
        :param nb_threads:
        :param nb_jobs:
        :param cpu_load:
        :param nb_cpu:
        :param latency_target:
        :param latency_window:
        :param latency_percentile:
        :param latency_run:
        :param buffer_compress_percentage:
        """

        # Input validation
        if (not (cpu_load is None) and (nb_cpu is None)) or ((cpu_load is None) and not (nb_cpu is None)):
            raise ValueError('cpu_load and nb_cpu must be set together')

        if nb_jobs is None:
            nb_jobs = nb_disks

        # Contains the global parameters
        self.glob = FioJob('global')

        # Set the global ioengine
        self.glob.ioengine = FioIoEngine.create('libaio')

        # Set the tests time and set the job to run for the specified time
        # Same as vdbench 'elapsed = nn'
        self.glob.time_based = True
        self.glob.runtime = testing_time

        # vdbench 'warmup = n'
        if warmup_time is not None:
            self.glob.ramp_time = warmup_time

        # Stats output
        self.glob.group_reporting = True

        #
        # Set read-write mode
        #
        if read_percentage == 0 and seek_percentage == 0:
            # Sequential write
            self.glob.readwrite = FioReadWrite.create('write')

        elif read_percentage == 0 and seek_percentage == 100:
            # 100% random writes
            self.glob.readwrite = FioReadWrite.create('randwrite')

        elif read_percentage == 0:
            # random writes
            self.glob.readwrite = FioReadWrite.create('randwrite')
            self.glob.percentage_random = FioPercentageRandom([seek_percentage])

        elif read_percentage == 100 and seek_percentage == 0:
            # Sequential read
            self.glob.readwrite = FioReadWrite.create('read')

        elif read_percentage == 100 and seek_percentage == 100:
            # 100% random read
            self.glob.readwrite = FioReadWrite.create('randread')

        elif read_percentage == 100:
            # random read
            self.glob.readwrite = FioReadWrite.create('randread')
            self.glob.percentage_random = FioPercentageRandom([seek_percentage])

        else:
            # mix read/write
            self.glob.readwrite = FioReadWrite.create('randrw')
            self.glob.percentage_random = FioPercentageRandom([seek_percentage])
            self.glob.rwmixread = read_percentage

        # vdbench 'xfersize = n'
        self.glob.blocksize = FioSize(block_size)

        # vdbench 'iorate = n'
        if io_rate is not None:
            self.glob.rate_iops = FioRateIops(io_rate)

        # vdbench 'openflags = o_direct'
        self.glob.direct = True

        # fsync
        self.glob.fsync = 0

        # buffered
        self.glob.buffered = False

        # vdbench 'data_errors'
        self.glob.continue_on_error = FioContinueOnError.create('all')

        # Set 64 bit random generator
        #
        # 2019/06/27
        #   On jobs that require a larger random number space fio
        #   would issue a warning and switch to tausworthe64 instead
        #   of the default tausworthe. To avoid the spurious warning
        #   we explicitly set tausworthe64 for all tests.
        #
        self.glob.random_generator = FioRandomGenerator.create('tausworthe64')

        # Latency percentiles
        self.glob.lat_percentiles = True

        if latency_target is not None:
            self.glob.latency_target = latency_target

        if latency_window is not None:
            self.glob.latency_window = latency_window

        if latency_percentile is not None:
            self.glob.latency_percentile = latency_percentile

        if latency_run is not None:
            self.glob.latency_run = latency_run

        if buffer_compress_percentage is not None:
            self.glob.buffer_compress_percentage = buffer_compress_percentage

        if dedupe_percentage is not None:
            self.glob.dedupe_percentage = dedupe_percentage

        #
        # Contains job specific parameters
        #
        self.jobs = []

        # Add DISK jobs
        # --------------------------------
        devices = self.__sd_devices(nb_disks)
        for i in range(min(nb_jobs, nb_disks)):
            job = FioJob('job%d' % i)

            # vdbench 'lun = path'
            job.filename = [Path(device) for device in devices[i::nb_jobs]]

            # vdbench 'vdbench range = (0,n)'
            job.size = FioSize('%d%%' % working_set)

            # vdbench 'threads = n'
            if nb_threads is not None:
                job.iodepth = nb_threads

            # Add subordinate jobqq
            self.jobs.append(job)

        # Add CPUIO jobs
        # --------------------------------
        if cpu_load is not None and nb_cpu is not None:
            for index in range(0, nb_cpu):

                # Set job name
                job = FioJob('cpu%d' % index)

                # Set the ioengine to cpuio
                job.ioengine = FioIoEngine.create('cpuio')

                # Set the cpu load
                job.cpuload = cpu_load

                # Set norandommap
                #
                # 2019/06/27
                #   It was discovered that profiles with both disk i/o and cpu i/o
                #   require the norandomap option. This can be set globally or a the
                #   the local job level. We set it a the local level to avoid
                #   impacting the disk io jobs.
                #
                job.norandommap = True

                # Add subordinate job
                self.jobs.append(job)

    @typechecked
    def write(self, path: Path, header: str = None):
        """ Write config to a file
        
        :param path: Target output file.
        :param header: Comment header to add to the file.
        :return: 
        """
        try:
            with path.open(mode='w') as file:
                if header:
                    file.write(header+'\n')
                file.write(str(self))
            file.close()

        except (OSError, IOError):
            raise

        except Exception:
            raise

    def __str__(self):
        value = str(self.glob)
        for job in self.jobs:
            value += '\n' + str(job)
        return value

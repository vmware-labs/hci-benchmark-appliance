import re

from typeguard import typechecked

from fioconfig.fiosize import FioSize

FIOBSSPLIT_PATTERN_1 = re.compile(r'([0-9]+k)/(100|[0-9]{1,2}|$)', re.IGNORECASE)


class FioBsSplit(object):

    def __init__(self, value: str):
        self.bssplit = value

    #
    # Properties
    #
    @property
    def bssplit(self):
        return self._bssplit

    @bssplit.setter
    @typechecked()
    def bssplit(self, value: str):
        self._bssplit = []
        for item in value.split(':'):
            result = FIOBSSPLIT_PATTERN_1.fullmatch(item)
            if result:
                if result.group(2):
                    self._bssplit.append((FioSize(result.group(1)), int(result.group(2))))
                else:
                    self._bssplit.append((FioSize(result.group(1)), None))
                continue

            raise ValueError('Class FioBsSplit '
                             'Method {inspect.getframeinfo(inspect.currentframe()).function} '
                             'Input does not match a known pattern '
                             'Received: %s' % value)

    #
    # Builtin
    #
    def __str__(self) -> str:
        value = ''
        first = True
        for bsize, percentage in self._bssplit:
            if percentage is None:
                percentage = ''
            if first:
                value += '%s/%s' % (str(bsize), percentage)
                first = False
            else:
                value += ':%s/%s' % (str(bsize), percentage)
        return value




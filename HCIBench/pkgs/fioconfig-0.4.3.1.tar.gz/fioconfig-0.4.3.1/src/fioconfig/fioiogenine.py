import inspect

from enum import Enum
from typeguard import typechecked
from typing import List


class FioIoEngine(Enum):
    """ FIO IO Engine
        Desc:   Defines how the job issues I/O to the file.
        Values: - sync
                - psync = auto()
                - vsync = auto()
                - pvsync = auto()
                - pvsync2 = auto()
                - libaio = auto()
                - posixaio = auto()
                - solarisaio = auto()
                - windowsaio = auto()
                - mmap = auto()
                - splice = auto()
                - sg = auto()
                - null = auto()
                - net = auto()
                - netsplice = auto()
                - cpuio = auto()
                - guasi = auto()
                - rdma = auto()
                - falloc = auto()
                - ftruncate = auto()
                - e4defrag = auto()
                - rados = auto()
                - bd = auto()
                - http = auto()
                - gfapi = auto()
                - gfapi_async = auto()
                - libhdfs = auto()
                - mtd = auto()
                - pmemblk = auto()
                - dev_dax = auto()
                - external = auto()
                - filecreate = auto()
                - libpmem = auto()The following types are defined:
        Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#i-o-engine
        """
    sync = 1
    psync = 2
    vsync = 3
    pvsync = 4
    pvsync2 = 5
    libaio = 6
    posixaio = 7
    solarisaio = 8
    windowsaio = 9
    mmap = 10
    splice = 11
    sg = 12
    null = 13
    net = 14
    netsplice = 15
    cpuio = 16
    guasi = 17
    rdma = 18
    falloc = 19
    ftruncate = 20
    e4defrag = 21
    rados = 22
    rbd = 23
    http = 24
    gfapi = 25
    gfapi_async = 26
    libhdfs = 27
    mtd = 28
    pmemblk = 29
    dev_dax = 30
    external = 31
    filecreate = 32
    libpmem = 33

    @classmethod
    @typechecked
    def create(cls, name: str) -> 'FioIoEngine':
        for item in cls:
            if item.name == name:
                return item
        raise ValueError('Enumeration FioIoEngine',
                         'Method %s' % inspect.getframeinfo(inspect.currentframe()).function,
                         'Input does not match a known type',
                         'Received {name}')

    @classmethod
    @typechecked
    def has_name(cls, name: str) -> bool:
        return any(name == item.name for item in cls)

    @classmethod
    @typechecked
    def has_value(cls, value: int) -> bool:
        return any(value == item.value for item in cls)

    @classmethod
    @typechecked
    def get_all_member(cls) -> List['FioIoEngine']:
        return [item for item in cls]

    @classmethod
    @typechecked
    def get_all_name(cls) -> List[str]:
        return [item.name for item in cls]

    @classmethod
    @typechecked
    def get_all_value(cls) -> List[int]:
        return [item.value for item in cls]

    @typechecked
    def __str__(self) -> str:
        switch = {
            FioIoEngine.sync.value: 'sync',
            FioIoEngine.psync.value: 'psync',
            FioIoEngine.vsync.value: 'vsync',
            FioIoEngine.pvsync.value: 'pvsync',
            FioIoEngine.pvsync2.value: 'pvsync2',
            FioIoEngine.libaio.value: 'libaio',
            FioIoEngine.posixaio.value: 'posixaio',
            FioIoEngine.solarisaio.value: 'solarisaio',
            FioIoEngine.windowsaio.value: 'fwindowsaio',
            FioIoEngine.mmap.value: 'mmap',
            FioIoEngine.splice.value: 'splice',
            FioIoEngine.sg.value: 'sg',
            FioIoEngine.null.value: 'null',
            FioIoEngine.net.value: 'net',
            FioIoEngine.netsplice.value: 'netsplice',
            FioIoEngine.cpuio.value: 'cpuio',
            FioIoEngine.guasi.value: 'guasi',
            FioIoEngine.rdma.value: 'rdma',
            FioIoEngine.falloc.value: 'falloc',
            FioIoEngine.ftruncate.value: 'ftruncate',
            FioIoEngine.e4defrag.value: 'e4defrag',
            FioIoEngine.rados.value: 'rados',
            FioIoEngine.rbd.value: 'rbd',
            FioIoEngine.http.value: 'http',
            FioIoEngine.gfapi.value: 'gfapi',
            FioIoEngine.gfapi_async.value: 'gfapi_async',
            FioIoEngine.libhdfs.value: 'libhdfs',
            FioIoEngine.mtd.value: 'mtd',
            FioIoEngine.pmemblk.value: 'pmemblk',
            FioIoEngine.dev_dax.value: 'dev-dax',
            FioIoEngine.external.value: 'external',
            FioIoEngine.filecreate.value: 'filecreate',
            FioIoEngine.libpmem.value: 'libpmem',
        }
        return switch.get(self.value)

    def __repr__(self):
        return self.__str__()

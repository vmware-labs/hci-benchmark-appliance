from unittest import TestCase


class TestFioPercentageRandom(TestCase):
    def test_percentage_random(self):
        # Todo
        pass


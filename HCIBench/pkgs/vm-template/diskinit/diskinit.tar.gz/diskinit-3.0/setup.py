import codecs
import os

from setuptools import setup, find_packages

here = os.path.abspath(os.path.dirname(__file__))


def read(*parts):
    # intentionally *not* adding an encoding option to open, See:
    #   https://github.com/pypa/virtualenv/issues/201#issuecomment-3145690
    with codecs.open(os.path.join(here, *parts), 'r') as fp:
        return fp.read()


# Read the contents of the README file
long_description = read('README.md')

setup(
    use_scm_version=True,

    name='diskinit',
    description='Python tool to initialize disks and calculate the time required.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='http://www.vmware.com/',
    license='MIT',
    author='Charles Lee',
    author_email='charlesl@vmware.com',

    package_dir={"": "src"},
    packages=find_packages(
        where="src",
        exclude=["contrib", "docs", "tests*", "tasks"],
    ),

    entry_points={
        "console_scripts": [
            "diskinit=diskinit:main"
        ],
    },

    setup_requires=['setuptools_scm'],
    install_requires=[
        "enum34 >= 1.1.6",
        "typing >= 3.6.6",
        "pathlib2 >= 2.3.3",
        "pyyaml >= 5.1",
        "netifaces >= 0.10.9"
    ],

    python_requires='>=2.7'
)

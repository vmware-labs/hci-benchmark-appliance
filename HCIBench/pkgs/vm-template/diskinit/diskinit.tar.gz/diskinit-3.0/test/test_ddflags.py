from unittest import TestCase

from diskinit.resources.ddflags import DDFlags


class TestDDFlags(TestCase):

    def setUp(self):
        self.flags_valid = ['append',
                            'cio',
                            'direct',
                            'directory',
                            'dsync',
                            'sync',
                            'nocache',
                            'nonblock',
                            'noatime',
                            'noctty',
                            'nofollow',
                            'nolinks',
                            'binary',
                            'text',
                            'fullblock',
                            'count_bytes',
                            'skip_bytes',
                            'seek_bytes']

        self.flags_invalid = ['add',
                              'fio',
                              'indirect',
                              'folder',
                              'async',
                              'cache']

    def test_get_all_member(self):
        ddflags = DDFlags.get_all_member()

        for ddflag in ddflags:
            self.assertIn(str(ddflag), self.flags_valid, "missing a flag: %s" % ddflag)

        for flag in self.flags_valid:
            self.assertIn(DDFlags.create(flag), ddflags, "test flags missing a flag: %s" % flag)

    def test_get_all_name(self):
        dd_names = DDFlags.get_all_name()

        for name in dd_names:
            self.assertIn(name, self.flags_valid, "returned an unexpected name: %s" % name)

        for flag in self.flags_valid:
            self.assertIn(flag, dd_names, "missing a flag: %s" % flag)

    def test_create(self):
        for name in self.flags_valid:
            try:
                flag = DDFlags.create(name)
            except ValueError:
                self.fail("unable to create flag for: %s" % name)
            else:
                self.assertIs(flag.name, name, "flag name did not match for: %s" % name)

    def test_create_set(self):

        # Empty string
        self.assertFalse(DDFlags.create_set(''), 'empty not empty')

        # Combination of valid flags
        for i in range(0, len(self.flags_valid) - 1):
            for j in range(i+1, len(self.flags_valid)):
                test = ''
                for flag in self.flags_valid[i:j]:
                    test += flag + ','
                test = test[:-1]
                self.assertSetEqual(DDFlags.create_set(test),
                                    set([DDFlags.create(x) for x in self.flags_valid[i:j]]),
                                    'sets did not match with [%s]' % self.flags_valid[i:j])

        # Combination of invalid flags
        for i in range(0, len(self.flags_invalid) - 1):
            for j in range(i+1, len(self.flags_invalid)):
                test = ''
                for flag in self.flags_invalid[i:j]:
                    test += flag + ','
                test = test[:-1]
                with self.assertRaises(ValueError):
                    DDFlags.create_set(test)


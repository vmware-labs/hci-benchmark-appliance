from unittest import TestCase


class TestDdResult(TestCase):
    foo1 = "dd: error writing '/dev/sdb': No space left on device\n" + \
           "error writing output file\n" + \
           "2621441+0 records in\n" + \
           "2621440+0 records out\n" + \
           "10737418240 bytes (11 GB, 10 GiB) copied, 33.8221 s, 317 MB/s\n"

    foo2 = "100000000+0 records in\n" + \
           "100000000+0 records out\n" + \
           "51200000000 bytes transferred in 202.051932 secs (253400200 bytes/sec)"
    pass

import shutil
import tempfile
import uuid

from pathlib2 import Path
from unittest import TestCase

from diskinit.resources.ddflags import DDFlags
from diskinit.methods.ddzerodiskinit import DdZeroDiskInit


class TestDdZeroDiskInit(TestCase):

    def setUp(self):
        # Create a temporary directory
        self.test_dir = tempfile.mkdtemp()

        # Create test files
        self.file_tmp = tempfile.NamedTemporaryFile()
        self.file_valid = self.file_tmp.name
        self.file_invalid = str(Path(self.test_dir).joinpath(str(uuid.uuid4())))

        # DD flags
        self.dd_flags = DDFlags.get_all_member()
        self.dd_flag_names = DDFlags.get_all_name()

    def tearDown(self):
        # Remove the directory after the test
        shutil.rmtree(self.test_dir)

    def test_device(self):
        # Non-existent device
        with self.assertRaises(ValueError):
            DdZeroDiskInit(self.file_invalid)

        # Existing device
        self.assertEqual(DdZeroDiskInit(self.file_valid).device, self.file_valid)

    def test_dd_iflag(self):
        for flag in DDFlags.get_all_member():
            self.fail()

    def test_dd_oflag(self):
        self.fail()

    def test_dd_bs(self):
        self.fail()

    def test_run(self):
        self.fail()


import json
import os
import tempfile
import uuid

from pathlib2 import Path
from unittest import TestCase

from diskinit.methods.openssldiskinit import DdOpensslDiskInit


class TestOpensslDiskInit(TestCase):

    @classmethod
    def setUpClass(cls):
        data = json.loads(Path('test_opensslDiskInit_data.json').read_bytes())
        cls.devices = data.get("device", [])
        cls.paths = data.get("path", [])
        cls.ciphers = data.get("cipher", [])

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        os.removedirs(self.tmp)

    def test___init___01(self):
        for d in self.devices:
            self.assertIsNotNone(DdOpensslDiskInit(d))

    def test___init___02(self):
        for d in self.devices:
            for p in self.paths:
                self.assertIsNotNone(DdOpensslDiskInit(device=d, path=p))

    def test___init___03(self):
        for d in self.devices:
            for c in self.ciphers:
                self.assertIsNotNone(DdOpensslDiskInit(device=d, cipher=c))

    def test___init___04(self):
        for d in self.devices:
            for p in self.paths:
                for c in self.ciphers:
                    self.assertIsNotNone(DdOpensslDiskInit(device=d, path=p, cipher=c))

    def test_cipher_01(self):
        for d in self.devices:
            for c in self.ciphers:
                self.assertEqual(DdOpensslDiskInit(device=d, cipher=c).cipher, c)

    def test_device_01(self):
        data = [True, False, 1, 1.0, list(), dict()]
        for d in data:
            with self.assertRaises(TypeError):
                DdOpensslDiskInit(device=d)

    def test_device_02(self):
        f = str(Path(self.tmp, str(uuid.uuid4())))
        with self.assertRaises(ValueError):
            DdOpensslDiskInit(device=f)

    def test_device_03(self):
        for d in self.devices:
            self.assertEqual(DdOpensslDiskInit(device=d).device, d)

    def test_path_01(self):
        data = [True, False, 1, 1.0, list(), dict()]
        for d in self.devices:
            for p in data:
                with self.assertRaises(TypeError):
                    DdOpensslDiskInit(device=d, path=p)

    def test_path(self):
        f = str(Path(self.tmp, str(uuid.uuid4())))
        with self.assertRaises(ValueError):
            DdOpensslDiskInit(device=f)

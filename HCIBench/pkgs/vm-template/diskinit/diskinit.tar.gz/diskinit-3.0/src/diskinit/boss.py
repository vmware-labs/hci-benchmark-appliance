import logging
import Queue
import signal
import time

from contextlib import contextmanager
from diskstatus import DiskStatus
from pathlib2 import Path
from serviceexit import ServiceExit
from worker import Worker


# noinspection PyUnusedLocal,PyUnusedLocal
def service_shutdown(signum, frame):
    # print('Caught signal %d' % signum)
    raise ServiceExit


class Boss(object):

    @contextmanager
    def sigint_handler(self):

        original_sigint_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, service_shutdown)
        try:
            yield
        except ServiceExit:
            # print('Caught Ctrl-C, trying graceful shutdown')
            for thread in self.threads:
                thread.shutdown_flag.set()

        finally:
            # print('Returning control to default signal handler')
            signal.signal(signal.SIGINT, original_sigint_handler)

    def __init__(self, result, threads=1, **kwargs):
        # type: (Path, int, **int) -> None
        self.jobs = Queue.Queue()
        self.results = Queue.Queue()
        self.nb_threads = threads
        self.threads = []
        self.diskstatus = DiskStatus(result)
        self.logger = logging.getLogger(__name__)
        self.logger.info("Created with %d threads" % self.nb_threads)

    def process(self):
        # type: () -> list

        results = Queue.Queue()
        nb_jobs = self.jobs.qsize()

        # Create threads
        for tid in range(0, self.nb_threads):
            thread = Worker(tid, self.jobs, results)
            # Using deamon threads is a bit ugly, but there is no elegant way
            # to interrupt a python thread doing a system call. If the call is very
            # long running, we are stuck waiting. Using deamon threads causes
            # the thread to be killed when the main program exits.
            thread.daemon = True
            thread.start()
            self.logger.info("Worker %d created and started" % tid)
            self.threads.append(thread)

        # Wait for job completion
        with self.sigint_handler():

            self.logger.info('Waiting for queue to empty')
            while self.results.qsize() < nb_jobs:
                time.sleep(1)
                while not results.empty():
                    result = results.get()
                    self.logger.info(result)
                    self.diskstatus.add(result)
                    self.results.put(result)

            # Process results
            while not results.empty():
                self.logger.info(result)
                result = results.get()
                self.diskstatus.add(result)
                self.results.put(result)

            # Wake up workers
            self.logger.info('Queue is empty, waking up workers for graceful exit')
            for thread in self.threads:
                thread.shutdown_flag.set()
            self.jobs.put(None)

            # Join threads
            for t in self.threads:
                t.join()
            self.logger.info('All workers joined')

        # Return results
        self.logger.debug("Returning %d results" % self.results.qsize())
        return list(self.results.queue)

    def add_work(self, jobs):
        self.logger.info("Adding %d jobs" % len(jobs))
        for job in jobs:
            self.jobs.put(job)

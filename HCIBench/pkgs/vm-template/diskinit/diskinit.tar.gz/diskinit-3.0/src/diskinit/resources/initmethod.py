
from enum import Enum
from typing import List


class InitMethod(Enum):
    """ Enumeration class for the valid initialization methods """

    ''' fio based methods '''
    fio_zero = 'fio_zero'
    fio_random = 'fio_random'
    fio_random_dedupe = 'fio_random_dedupe'

    ''' dd based methods '''
    dd_zero = 'dd_zero'
    dd_random = 'dd_random'
    dd_openssl = 'dd_openssl'

    @classmethod
    def get_all_name(cls):
        # type: () -> List[str]
        return [name for name, member in cls.__members__.items() if member.name == name]

    @classmethod
    def get_all_member(cls):
        # type: () -> List['DiskInitMethod']
        return [member for name, member in cls.__members__.items() if member.name == name]

    @classmethod
    def create(cls, name):
        # type: () -> 'DiskInitMethod'
        for item in cls.get_all_member():
            if item.name == name:
                return item
        raise ValueError("Enum DDFlags received an invalid name %s not in [%s]" % (name, cls.get_all_name()))

    def __str__(self):
        # type: () -> str
        return self.value

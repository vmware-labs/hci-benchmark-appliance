import logging
import subprocess

from pathlib2 import Path

from diskinit.resources.initmethod import InitMethod
from fioclass import FioClass
from fioresult import FioResult
from initclass import InitClass


class FioDiskInit(InitClass, FioClass):
    """ Fio Random Disk Initialization """

    def __cmd(self):
        # type: () -> str
        """ command line command string """

        ''' buffer_compress_percentage '''
        if self.buffer_compress_percentage is not None:
            bcp = "--buffer_compress_percentage=%d " % self.buffer_compress_percentage
        else:
            bcp = ''

        ''' dedupe_percentage '''
        if self.dedupe_percentage is not None:
            dp = "--dedupe_percentage=%d " % self.dedupe_percentage
        else:
            dp = ''

        ''' randrepeat '''
        if self.randrepeat is not None and self.randrepeat is False:
            rr = "--randrepeat=0 "
        else:
            rr = ''

        ''' zero_buffers '''
        if self.zero_buffers:
            zb = '--zero_buffers '
        else:
            zb = ''

        return "%s " % self.path + \
               "--name=%s " % self.device + \
               "--filename=%s " % self.device + \
               "--ioengine=%s " % self.ioengine + \
               "--rw=write " + \
               "--direct=1 " + \
               "--thread " + \
               "--iodepth=%d " % self.iodepth + \
               "%s" % bcp + \
               "%s" % dp + \
               "%s" % rr + \
               "%s" % zb + \
               "--blocksize=%d " % self.bs + \
               "--blockalign=4096 " + \
               "--output-format=json"

    def __init__(self, device, **kwargs):
        # type: (str, **int) -> None
        """ Object to test disk initialization using FIO """

        ''' call parents '''
        InitClass.__init__(self, InitMethod.fio_random)
        FioClass.__init__(self, **kwargs)

        ''' block device output target '''
        self.device = device

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Created with [%s]" % self.device)

    def run(self):
        self.logger.debug("Run [%s]" % self.__cmd())
        return FioResult(subprocess.Popen(self.__cmd(),
                                          stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE,
                                          shell=True).communicate(),
                         self.device,
                         self.method)

    def __str__(self):
        return "%s %s FioRandomDiskInit [%s]" % (InitClass.__str__(self),
                                                 FioClass.__str__(self),
                                                 self.device)

    @property
    def device(self):
        # type: () -> str
        return self._device

    @device.setter
    def device(self, device):
        # type: (str) -> None
        if not Path(device).exists():
            raise ValueError("device does not exist")
        self._device = device

import datetime

from abc import ABCMeta, abstractmethod

from diskinit.resources.initmethod import InitMethod


class Result(object):
    """ Abstract class for results """

    __metaclass__ = ABCMeta

    def __init__(self, device, method):
        # type: (str, InitMethod) -> None
        """ Base Constructor """

        ''' device '''
        self.device = device

        ''' method '''
        self.method = method

        ''' date and time '''
        self.datetime = datetime.datetime.now()

    @abstractmethod
    def get_datetime(self):
        # type: () -> str
        raise NotImplementedError('must override in child class')

    @abstractmethod
    def get_device(self):
        # type: () -> str
        raise NotImplementedError('must override in child class')

    @abstractmethod
    def get_method(self):
        # type: () -> str
        raise NotImplementedError('must override in child class')

    @abstractmethod
    def get_bytes(self):
        # type: () -> int
        raise NotImplementedError('must override in child class')

    @abstractmethod
    def get_rate(self):
        # type: () -> str
        raise NotImplementedError('must override in child class')

    @abstractmethod
    def __str__(self):
        raise NotImplementedError('must override in child class')

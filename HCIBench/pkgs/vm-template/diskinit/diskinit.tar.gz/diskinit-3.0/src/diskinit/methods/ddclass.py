import logging

from abc import ABCMeta
from typing import Set

from diskinit.resources.ddflags import DDFlags


class DdClass(object):

    """ Abstract class for methods that use DD """
    __metaclass__ = ABCMeta
    __valid_bs = [4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576]

    @staticmethod
    def __flags_to_str(flags):
        # type: (Set[DDFlags]) -> str
        dd_flags = ''
        if flags:
            for flag in flags:
                if not isinstance(flag, DDFlags):
                    raise TypeError("flag is not a valid dd flag")
                dd_flags += "%s," % flag
            dd_flags = dd_flags[:-1]
        return dd_flags

    def __init__(self, **kwargs):
        # type: (**int) -> None
        """ Base Constructor """

        ''' dd input flags '''
        self.dd_iflag = kwargs.get('dd_iflag', [])

        ''' dd output flags '''
        self.dd_oflag = kwargs.get('dd_oflag', [])

        ''' dd block size '''
        self.dd_bs = int(kwargs.get('dd_bs', 65536))

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Created with [%s] [%s] [%d]" % (self.dd_iflag, self.dd_oflag, self.dd_bs))

    def __str__(self):
        # type: () -> str
        return "DdMethod [%s] [%s] [%d]" % (self.dd_iflag_str(),
                                            self.dd_oflag_str(),
                                            self.dd_bs)

    def dd_iflag_str(self):
        # type: () -> str
        return self.__flags_to_str(self._dd_iflag)

    def dd_oflag_str(self):
        # type: () -> str
        return self.__flags_to_str(self._dd_oflag)

    ''' dd input flags '''
    @property
    def dd_iflag(self):
        # type: () -> Set[DDFlags]
        return self._dd_iflag

    @dd_iflag.setter
    def dd_iflag(self, flags):
        # type: (Set[DDFlags]) -> None
        self._dd_iflag = flags

    ''' dd output flags '''
    @property
    def dd_oflag(self):
        # type: () -> Set[DDFlags]
        return self._dd_oflag

    @dd_oflag.setter
    def dd_oflag(self, flags):
        # type: (Set[DDFlags]) -> None
        self._dd_oflag = flags

    ''' dd block size '''
    @property
    def dd_bs(self):
        # type: () -> int
        return self._dd_bs

    @dd_bs.setter
    def dd_bs(self, dd_bs):
        # type: (int) -> None
        if dd_bs not in self.__valid_bs:
            raise ValueError("bs must be in %s" % self.__valid_bs)
        self._dd_bs = dd_bs

#! /usr/bin/env python

from pkg_resources import get_distribution, DistributionNotFound
try:
    __version__ = get_distribution("diskinit").version
except DistributionNotFound:
    __version__ = "Unknown Version"

__title__ = 'diskinit'
__description__ = 'Python tool to initialize disks and calculate the time required.'
__url__ = 'http://www.vmware.com/'
__build__ = 0x00031
__author__ = 'Charles Lee'
__author_email__ = 'charlesl@vmware.com'
__license__ = 'MIT'
__cake__ = u'\u2728 \U0001f370 \u2728'

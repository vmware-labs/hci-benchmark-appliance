import logging

from abc import ABCMeta
from pathlib2 import Path

from diskinit.resources.fioioengine import FioIoEngine


class FioClass(object):
    """ Abstract class for methods that use Fio """
    __metaclass__ = ABCMeta
    __valid_bs = [4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576]

    def __init__(self, **kwargs):
        # type: (**int) -> None
        """ Base Constructor """

        ''' fio binary path'''
        self.path = kwargs.get('fio_path', '/usr/local/bin/fio')

        ''' ioengine '''
        self.ioengine = kwargs.get('fio_ioengine', FioIoEngine.libaio)

        ''' iodepth '''
        self.iodepth = kwargs.get('fio_iodepth', 4)

        ''' buffer_compress_percentage '''
        self.buffer_compress_percentage = kwargs.get('fio_buffer_compress_percentage', None)

        ''' dedupe_percentage '''
        self.dedupe_percentage = kwargs.get('fio_dedupe_percentage', None)

        ''' randrepeat '''
        self.randrepeat = kwargs.get('fio_randrepeat', None)

        ''' zero_buffers '''
        self.zero_buffers = kwargs.get('fio_zero_buffers', None)

        ''' block size '''
        self.bs = kwargs.get('fio_bs', 65536)

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Created with [%s] [%s] [%d]" % (self.path, self.ioengine, self.bs))

    def __str__(self):
        # type: () -> str
        return "FioClass [%s] [%s] [%d] [%s] [%s] [%s] [%s] [%d]" % (self.path,
                                                                     self.ioengine,
                                                                     self.iodepth,
                                                                     self.buffer_compress_percentage,
                                                                     self.dedupe_percentage,
                                                                     self.randrepeat,
                                                                     self.zero_buffers,
                                                                     self.bs)

    ''' fio path '''
    @property
    def path(self):
        # type: () -> str
        return self._path

    @path.setter
    def path(self, path):
        # type: (str) -> None
        if not Path(path).exists():
            raise ValueError("path does not exist")
        self._path = path

    ''' ioengine  '''
    @property
    def ioengine(self):
        # type: () -> FioIoEngine
        return self._ioengine

    @ioengine.setter
    def ioengine(self, ioengine):
        # type: (FioIoEngine) -> None
        self._ioengine = ioengine

    ''' iodepth '''
    @property
    def iodepth(self):
        # type: () -> int
        return self._iodepth

    @iodepth.setter
    def iodepth(self, iodepth):
        # type: (int) -> None
        self._iodepth = iodepth

    ''' block size '''
    @property
    def bs(self):
        # type: () -> int
        return self._bs

    @bs.setter
    def bs(self, bs):
        # type: (int) -> None
        if bs not in self.__valid_bs:
            raise ValueError("bs must be in %s" % self.__valid_bs)
        self._bs = bs

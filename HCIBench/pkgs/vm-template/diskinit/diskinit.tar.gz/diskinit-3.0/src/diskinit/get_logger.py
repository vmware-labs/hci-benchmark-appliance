
import logging

from logging.handlers import RotatingFileHandler
from pathlib2 import Path


def get_logger(path, size=102400, count=5):
    # type: (Path, int, int) -> logging
    """ Create root logger """

    ''' Create logger'''
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    ''' Add file handler '''
    f_handler = RotatingFileHandler(str(path), maxBytes=size, backupCount=count)
    f_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s'))
    logger.addHandler(f_handler)

    return logger


def close_logger(logger):
    # type: (logging) -> None
    for handler in logger.handlers[:]:
        handler.close()
        logger.removeHandler(handler)

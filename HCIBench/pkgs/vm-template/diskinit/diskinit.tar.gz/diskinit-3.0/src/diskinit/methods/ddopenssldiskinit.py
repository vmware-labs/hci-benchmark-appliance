import logging
import subprocess

from pathlib2 import Path

from ddclass import DdClass
from ddresult import DdResult
from initclass import InitClass
from diskinit.resources.initmethod import InitMethod


class DdOpensslDiskInit(InitClass, DdClass):

    def __cmd(self):
        return "%s enc " % self.path + \
               "-%s " % self.cipher + \
               "-pass pass:\"$(dd if=%s bs=128 count=1 2>/dev/null | base64)\" " % self.input_device + \
               "-nosalt " + \
               "< " + \
               "/dev/zero " + \
               "| " + \
               "dd " + \
               "%s" % (("iflag='%s' " % self.dd_iflag_str()) if self.dd_iflag else '') + \
               "of='%s' " % self.device + \
               "%s" % (("oflag='%s' " % self.dd_oflag_str()) if self.dd_oflag else '') + \
               "bs=%d" % self.dd_bs

    def __init__(self, device, path='/usr/bin/openssl', cipher='aes-256-ctr', input_device='/dev/urandom', **kwargs):
        """ Object to test disk initialization using OpenSSL """

        ''' call parents '''
        InitClass.__init__(self, InitMethod.dd_openssl)
        DdClass.__init__(self, **kwargs)

        ''' block device output target '''
        self.device = device

        ''' openssl binary path'''
        self.path = path

        ''' openssl cipher '''
        self.cipher = cipher

        ''' input device '''
        self.input_device = input_device

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Created with [%s] [%s] [%s] [%s]" % (self.device,
                                                                self.path,
                                                                self.cipher,
                                                                self.input_device))

    def run(self):
        self.logger.debug("Run [%s]" % self.__cmd())
        return DdResult(subprocess.Popen(self.__cmd(),
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE,
                                         shell=True).communicate(),
                        self.device,
                        self.method)

    def __str__(self):
        return "%s %s DdOpensslDiskInit [%s] [%s] [%s] [%s]" % (InitClass.__str__(self),
                                                                DdClass.__str__(self),
                                                                self.device,
                                                                self.path,
                                                                self.cipher,
                                                                self.input_device)

    ''' device '''
    @property
    def device(self):
        # type: () -> str
        return self._device

    @device.setter
    def device(self, device):
        # type: (str) -> None
        if not Path(device).exists():
            self.logger.error("device does not exist [%s]" % device)
            raise ValueError("device does not exist")
        self._device = device

    ''' openssl path '''
    @property
    def path(self):
        # type: () -> str
        return self._path

    @path.setter
    def path(self, path):
        # type: (str) -> None
        if not Path(path).is_file():
            self.logger.error("path does not exist [%s]" % path)
            raise ValueError("path does not exist")
        self._path = path

    ''' openssl cipher '''
    @property
    def cipher(self):
        # type: () -> str
        return self._cipher

    @cipher.setter
    def cipher(self, cipher):
        # type: (str) -> None
        self._cipher = cipher



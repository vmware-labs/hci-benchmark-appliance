#! /usr/bin/env python2
from __future__ import print_function

from time import time

from boss import Boss
from get_logger import get_logger, close_logger
from get_config import get_config
from util import get_sd_devices


def cli():
    """ Disk Init Tester CLI interface """

    ''' Get arguments '''
    config = get_config()

    ''' Get logger '''
    logger = get_logger(config['logfile'])

    ''' Log config '''
    for k, v in config.items():
        if k == 'method':
            v = v.__name__
        logger.debug("Parameter: %s: [%s]" % (k, v))

    ''' Start timing '''
    logger.info("Start timing")
    start = time()

    '''Create Boss, add work, and start workers'''
    logger.debug("Creating boss with %d worker threads" % config['threads'])
    boss = Boss(**config)

    ''' Add tasks to worker queue '''
    sd_devices = get_sd_devices()
    logger.info("There are %d devices to initialize" % len(sd_devices))
    logger.debug("SD devices: %s" % sd_devices)
    boss.add_work([config['method'](d, **config) for d in sd_devices])

    ''' Start workers '''
    logger.info('Starting workers')
    results = boss.process()
    logger.debug("Work complete")

    ''' End timing '''
    logger.info("End timing")
    end = time()

    ''' Print results '''
    print('Results:')
    for res in results:
        print(res)
        logger.debug('Result: %s' % res)
    print("Time: %f seconds" % (end - start))
    logger.info('Elapsed time: %f' % (end - start))

    ''' Close logger '''
    close_logger(logger)


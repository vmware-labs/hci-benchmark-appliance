import logging
import subprocess

from pathlib2 import Path

from ddresult import DdResult
from ddclass import DdClass
from diskinit.resources.initmethod import InitMethod
from initclass import InitClass


class DdRandomDiskInit(InitClass, DdClass):

    def __cmd(self):
        return "dd " + \
               "if='/dev/urandom' " + \
               "%s" % (("iflag='%s' " % self.dd_iflag_str()) if self.dd_iflag else '') + \
               "of='%s' " % self.device + \
               "%s" % (("oflag='%s' " % self.dd_oflag_str()) if self.dd_oflag else '') + \
               "bs=%d" % self.dd_bs

    def __init__(self, device, **kwargs):
        """ Object to test disk initialization using /dev/random """

        ''' call parents '''
        InitClass.__init__(self, InitMethod.dd_random)
        DdClass.__init__(self, **kwargs)

        ''' block device output target '''
        self.device = device

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Created with [%s]" % self.device)

    def run(self):
        self.logger.debug("Run [%s]" % self.__cmd())
        return DdResult(subprocess.Popen(self.__cmd(),
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE,
                                         shell=True).communicate(),
                        self.device,
                        self.method)

    def __str__(self):
        return "%s %s DdRandomDiskInit [%s]" % (InitClass.__str__(self),
                                                DdClass.__str__(self),
                                                self.device)

    '''
    Properties
    '''

    ''' device '''
    @property
    def device(self):
        # type: () -> str
        return self._device

    @device.setter
    def device(self, device):
        # type: (str) -> None
        if not Path(device).exists():
            self.logger.error("device does not exist [%s]" % device)
            raise ValueError("device does not exist")
        self._device = device



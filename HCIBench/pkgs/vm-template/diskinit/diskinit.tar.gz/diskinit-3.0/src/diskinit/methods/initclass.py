import logging

from abc import ABCMeta, abstractmethod

from diskinit.resources.initmethod import InitMethod


class InitClass(object):
    """ Abstract class for tasks """

    __metaclass__ = ABCMeta

    def __init__(self, method):
        # type: (InitMethod) -> None
        """ Base Constructor """

        ''' method '''
        self.method = method

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Created with [%s]" % self.method)

    @abstractmethod
    def run(self):
        raise NotImplementedError('must override in child class')

    @abstractmethod
    def __str__(self):
        # type: () -> str
        return "InitMethod [%s]" % self.method

from enum import Enum, unique
from typing import List, Set


@unique
class DDFlags(Enum):
    """ Enumeration class for the valid dd flags """
    ''' 
    Write in append mode, so that even if some other process is writing to this file, every dd write will append 
    to the current contents of the file. This flag makes sense only for output. If you combine this flag with the 
    "of=file" operand, you should also specify "conv=notrunc" unless you want the output file to be truncated before 
    being appended to.
    '''
    append = 'append'

    '''
    Use concurrent I/O mode for data. This mode performs direct I/O and drops the POSIX requirement to serialize all 
    I/O to the same file. A file cannot be opened in CIO mode and with a standard open at the same time.
    '''
    cio = 'cio'

    '''
    Use direct I/O for data, avoiding the buffer cache. Note that the kernel may impose restrictions on read or write 
    buffer sizes. For example, with an ext4 destination file system and a Linux-based kernel, using "oflag=direct" 
    will cause writes to fail with EINVAL if the output buffer size is not a multiple of 512.
    '''
    direct = 'direct'

    '''
    Fail unless the file is a directory. Most operating systems do not allow I/O to a directory, so this flag has 
    limited utility.
    '''
    directory = 'directory'

    '''
    Use synchronized I/O for data. For the output file, this forces a physical write of output data on each write. 
    For the input file, this flag can matter when reading from a remote file that has been written to synchronously 
    by some other process. Metadata (e.g., last-access and last-modified time) is not necessarily synchronized.
    '''
    dsync = 'dsync'

    '''
    Use synchronized I/O for both data and metadata.
    '''
    sync = 'sync'

    '''
    Request to discard the system data cache for a file. When count=0 all cached data for the file is specified, 
    otherwise the cache is dropped for the processed portion of the file. Also when count=0, failure to discard the 
    cache is diagnosed and reflected in the exit status.
    '''
    nocache = 'nocache'

    '''
    Use non-blocking I/O.
    '''
    nonblock = 'nonblock'

    '''
    Do not update the files access timestamp. See File timestamps. Some older file systems silently ignore this flag, 
    so it is a good idea to test it on your files before relying on it.
    '''
    noatime = 'noatime'

    '''
    Do not assign the file to be a controlling terminal for dd. This has no effect when the file is not a terminal. 
    On many hosts (e.g., GNU/Linux hosts), this option has no effect at all.
    '''
    noctty = 'noctty'

    '''
    Do not follow symbolic links.
    '''
    nofollow = 'nofollow'

    '''
    Fail if the file has multiple hard links.
    '''
    nolinks = 'nolinks'

    '''
    Use binary I/O. This option has an effect only on nonstandard platforms that distinguish binary from text I/O.
    '''
    binary = 'binary'

    '''
    Use text I/O. Like "binary", this option has no effect on standard platforms.
    '''
    text = 'text'

    '''
    Accumulate full blocks from input. The read system call may return early if a full block is not available. When 
    that happens, continue calling read to fill the remainder of the block. This flag can be used only with iflag. 
    This flag is useful with pipes for example as they may return short reads. In that case, this flag is needed to 
    ensure that a "count=" argument is interpreted as a block count rather than a count of read operations.
    '''
    fullblock = 'fullblock'

    '''
    Interpret the "count=" operand as a byte count, rather than a block count, which allows specifying a length that 
    is not a multiple of the I/O block size. This flag can be used only with iflag.
    '''
    count_bytes = 'count_bytes'

    '''
    Interpret the "skip=" operand as a byte count, rather than a block count, which allows specifying an offset that 
    is not a multiple of the I/O block size. This flag can be used only with iflag.
    '''
    skip_bytes = 'skip_bytes'

    '''
    Interpret the "seek=" operand as a byte count, rather than a block count, which allows specifying an offset that 
    is not a multiple of the I/O block size. This flag can be used only with oflag.
    '''
    seek_bytes = 'seek_bytes'

    @classmethod
    def get_all_name(cls):
        # type: () -> List[str]
        return [name for name, member in cls.__members__.items() if member.name == name]

    @classmethod
    def get_all_member(cls):
        # type: () -> List['DDFlags']
        return [member for name, member in cls.__members__.items() if member.name == name]

    @classmethod
    def create(cls, flag):
        # type: (str) -> 'DDFlags'
        for item in cls.get_all_member():
            if item.name == flag:
                return item
        raise ValueError("Enum DDFlags received an invalid name %s not in [%s]" % (flag, cls.get_all_name()))

    @classmethod
    def create_set(cls, flags):
        # type: (str) -> Set['DDFlags']
        return set([DDFlags.create(x.strip()) for x in flags.split(',') if x])

    def __str__(self):
        # type: () -> str
        return self.value


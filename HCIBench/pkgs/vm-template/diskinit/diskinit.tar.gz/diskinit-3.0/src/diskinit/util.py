
import re

from pathlib2 import Path
from typing import List


def get_nb_processors():
    # type: () -> int
    """ Returns the number of physical processors

    Ref:    https://stackoverflow.com/questions/1006289/how-to-find-out-the-number-of-cpus-using-python

    :return:    int
    """
    try:
        import multiprocessing
        return multiprocessing.cpu_count()
    except (ImportError, NotImplementedError):
        pass

    # try:
    #    import psutil
    #    return psutil.cpu_count()  # psutil.NUM_CPUS on old versions
    # except (ImportError, AttributeError):
    #    pass

    # Linux
    try:
        res = open('/proc/cpuinfo').read().count('processor\t:')
        if res > 0:
            return res
    except IOError:
        pass

    # Other UNIXes (heuristic)
    try:
        try:
            dmesg = open('/var/run/dmesg.boot').read()
        except IOError:
            import subprocess
            dmesg_process = subprocess.Popen(['dmesg'], stdout=subprocess.PIPE)
            dmesg = dmesg_process.communicate()[0]

        res = 0
        while '\ncpu' + str(res) + ':' in dmesg:
            res += 1

        if res > 0:
            return res
    except OSError:
        pass

    raise Exception('Cannot determine number of CPUs on this system')


def get_sd_devices(device='sd'):
    # type: (str) -> List[str]
    """Returns all devices that not have a partition.
    E.g.    A system with the following entries"

            /dev/sda
            /dev/sda1
            /dev/sdb
            /dev/sdb2
            /dev/sdc
            /dev/sdd

            Would return:

            ['/dev/sdc', '/dev/sdd']

    :return: list strings representing the path of a device
    """

    ''' regex for the device with no numbers '''
    re_1 = re.compile(r'/dev/%s[a-z]*$' % device, re.IGNORECASE)

    ''' regex for the device ending with a number '''
    re_2 = re.compile(r'\d+$')

    dir_list = [str(dev) for dev in sorted(Path('/dev').rglob(device+'*'))]
    dev_list = set([dev for dev in dir_list if re_1.search(dev) is not None])
    dev_partition = [re_2.sub('', dev) for dev in dir_list if re_2.search(dev)]
    return [dev for dev in dev_list if dev not in dev_partition]

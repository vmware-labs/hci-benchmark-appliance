import logging
import re

from typing import Tuple

from diskinit.resources.initmethod import InitMethod
from result import Result


class DdResult(Result):

    re_1 = re.compile(r'(\b\d+\+0)(?:[\s\S\w]|in)+?'
                      r'(\b\d+\+0)(?:[\s\S\D]|out)+?'
                      r'(\b\d+)(?:[\s\S\w]+?)'
                      r'(\b\d+.\d+)(?:[\s\S\w]+?)'
                      r'(\b\d+)(?:\s+)'
                      r'(\b.+/.+)\)',
                      re.IGNORECASE)

    # noinspection SpellCheckingInspection
    re_2 = re.compile(r'(?:[\s\S\w]*?)'
                      r'(\b\d+\+\d+)(?:[\s\S\w]|in)+?'
                      r'(\b\d+\+\d+)(?:[\s\S\D]|out)+?'
                      r'(\b\d+)[\s\S\w]+?(?:[\s\S\w]+copied,\s+)'
                      r'(\b\d+.\d+)(?:[\s\S\w])+?'
                      r'(\b\d+(?:|\.\d+))+(?:\s+)'
                      r'(\b[PTGMKB]{1,2}/s)', re.IGNORECASE)

    def __init__(self, popen_status, device, method):
        # type: (Tuple[str, str], str, InitMethod) -> None
        """ DdResult Constructor """

        ''' call parent constructor'''
        super(DdResult, self).__init__(device, method)

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Created with %s %s %s" % (self.device,
                                                     self.datetime.strftime("%Y-%m-%d %H:%M:%S:%f"),
                                                     self.method))

        self.logger.debug("DD output [%s]" % popen_status[1])

        ''' parse result '''
        try:
            result = self.re_1.search(popen_status[1])
            if result is not None:
                self.logger.debug('regex 1 match')

            else:
                result = self.re_2.search(popen_status[1])
                if result is not None:
                    self.logger.debug('regex 2 match')
                else:
                    raise ValueError("cannot parse the output")

            self.records_in = result.group(1)
            self.records_out = result.group(2)
            self.bytes = int(result.group(3))
            self.time_sec = float(result.group(4))
            self.xfer_speed = float(result.group(5))
            self.xfer_unit = result.group(6)
            self.logger.debug('Result %s %s %d %.2f %.2f %s' % (self.records_in,
                                                                self.records_out,
                                                                self.bytes,
                                                                self.time_sec,
                                                                self.xfer_speed,
                                                                self.xfer_unit))

        except ValueError:
            self.logger.error('Failed to parse stdout')
            self.records_in = 0
            self.records_out = 0
            self.bytes = 0
            self.time_sec = 0.0
            self.xfer_speed = 0.0
            self.xfer_unit = 'KB/s'

    def get_datetime(self):
        # type: () -> str
        return str(self.datetime)

    def get_device(self):
        # type: () -> str
        return self.device

    def get_method(self):
        # type: () -> str
        return str(self.method)

    def get_bytes(self):
        # type: () -> int
        return self.bytes

    def get_rate(self):
        # type: () -> str
        return "%.1f %s" % (self.xfer_speed, self.xfer_unit)

    def __str__(self):
        return "Device: %s " % self.device + \
               "Bytes: %d " % self.bytes + \
               "Time: %.1f " % self.time_sec + \
               "Rate: %.1f %s" % (self.xfer_speed, self.xfer_unit)

from enum import Enum, unique
from typing import List


@unique
class OsslCiphers(Enum):
    """ Enumeration class for the valid openssl block ciphers """
    
    aes_128_ecb = 'aes-128-ecb'
    aes_192_cbc = 'aes-192-cbc'
    aes_192_ecb = 'aes-192-ecb'
    aes_256_cbc = 'aes-256-cbc'
    aes_256_ecb = 'aes-256-ecb'
    base64 = 'base64'
    bf = 'bf'
    bf_cbc = 'bf-cbc'
    bf_cfb = 'bf-cfb'
    bf_ecb = 'bf-ecb'
    bf_ofb = 'bf-ofb'
    camellia_128_cbc = 'camellia-128-cbc'
    camellia_128_ecb = 'camellia-128-ecb'
    camellia_192_cbc = 'camellia-192-cbc'
    camellia_192_ecb = 'camellia-192-ecb'
    camellia_256_cbc = 'camellia-256-cbc'
    camellia_256_ecb = 'camellia-256-ecb'
    cast = 'cast'
    cast_cbc = 'cast-cbc'
    cast5_cbc = 'cast5-cbc'
    cast5_cfb = 'cast5-cfb'
    cast5_ecb = 'cast5-ecb'
    cast5_ofb = 'cast5-ofb'
    chacha = 'chacha'
    des = 'des'
    des_cbc = 'des-cbc'
    des_cfb = 'des-cfb'
    des_ecb = 'des-ecb'
    des_ede = 'des-ede'
    des_ede_cbc = 'des-ede-cbc'
    des_ede_cfb = 'des-ede-cfb'
    des_ede_ofb = 'des-ede-ofb'
    des_ede3 = 'des-ede3'
    des_ede3_cbc = 'des-ede3-cbc'
    des_ede3_cfb = 'des-ede3-cfb'
    des_ede3_ofb = 'des-ede3-ofb'
    des_ofb = 'des-ofb'
    des3 = 'des3'
    desx = 'desx'
    rc2 = 'rc2'
    rc2_40_cbc = 'rc2-40-cbc'
    rc2_64_cbc = 'rc2-64-cbc'
    rc2_cbc = 'rc2-cbc'
    rc2_cfb = 'rc2-cfb'
    rc2_ecb = 'rc2-ecb'
    rc2_ofb = 'rc2-ofb'
    rc4 = 'rc4'
    rc4_40 = 'rc4-40 '

    @classmethod
    def get_all_name(cls):
        # type: () -> List[str]
        return [name for name, member in cls.__members__.items() if member.name == name]

    @classmethod
    def get_all_member(cls):
        # type: () -> List['OsslCiphers']
        return [member for name, member in cls.__members__.items() if member.name == name]

    @classmethod
    def create(cls, name):
        # type: () -> 'OsslCiphers'
        for item in cls.get_all_member():
            if item.name == name:
                return item
        raise ValueError("Enum OsslCiphers received an invalid name %s not in [%s]" % (name, cls.get_all_name()))

    def __str__(self):
        # type: () -> str
        return self.value

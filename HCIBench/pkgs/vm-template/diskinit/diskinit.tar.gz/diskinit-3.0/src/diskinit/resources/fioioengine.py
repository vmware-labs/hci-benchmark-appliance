from enum import Enum, unique
from typing import List


@unique
class FioIoEngine(Enum):
    sync = 'sync'
    psync = 'psync'
    vsync = 'vsync'
    pvsync = 'pvsync'
    pvsync2 = 'pvsync2'
    io_uring = 'io_uring'
    libaio = 'libaio'
    posixaio = 'posixaio'
    solarisaio = 'solarisaio'
    windowsaio = 'windowsaio'
    mmap = 'mmap'
    splice = 'splice'
    sg = 'sg'
    null = 'null'
    net = 'net'
    netsplice = 'netsplice'
    cpuio = 'cpuio'
    guasi = 'guasi'
    rdma = 'rdma'
    falloc = 'falloc'
    ftruncate = 'ftruncate'
    e4defrag = 'e4defrag'
    rados = 'rados'
    rbd = 'rbd'
    http = 'http'
    gfapi = 'gfapi'
    gfapi_async = 'gfapi_async'
    libhdfs = 'libhdfs'
    mtd = 'mtd'
    pmemblk = 'pmemblk'
    dev_dax = 'dev-dax'
    external = 'external'
    filecreate = 'filecreate'
    libpmem = 'libpmem'
    ime_psync = 'ime_psync'
    ime_psyncv = 'ime_psyncv'
    ime_aio = 'ime_aio'
    libiscsi = 'libiscsi'
    nbd = 'nbd'

    @classmethod
    def get_all_name(cls):
        # type: () -> List[str]
        return [name for name, member in cls.__members__.items() if member.name == name]

    @classmethod
    def get_all_member(cls):
        # type: () -> List['FioIoEngine']
        return [member for name, member in cls.__members__.items() if member.name == name]

    @classmethod
    def create(cls, flag):
        # type: (str) -> 'FioIoEngine'
        for item in cls.get_all_member():
            if item.name == flag:
                return item
        raise ValueError("Enum FioIoEngine received an invalid name %s not in [%s]" % (flag, cls.get_all_name()))

    def __str__(self):
        # type: () -> str
        return self.value

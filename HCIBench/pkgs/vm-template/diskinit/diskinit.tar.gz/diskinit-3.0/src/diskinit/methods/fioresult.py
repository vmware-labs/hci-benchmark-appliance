import logging
import json

from typing import Tuple

from diskinit.resources.initmethod import InitMethod
from result import Result


class FioResult(Result):

    def __init__(self, popen_status, device, method):
        # type: (Tuple[str, str], str, InitMethod) -> None
        """ FioResult Constructor """

        ''' call parent constructor'''
        super(FioResult, self).__init__(device, method)

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Created with %s %s %s" % (self.device,
                                                     self.datetime.strftime("%Y-%m-%d %H:%M:%S:%f"),
                                                     self.method))
        ''' stdout '''
        self.stdout = popen_status[0]
        self.logger.debug(self.stdout if self.stdout else '')

        ''' stderr '''
        self.stderr = popen_status[1]
        self.logger.debug(self.stderr if self.stderr else '')

        ''' unit '''
        self.xfer_unit = 'KB/s'

        try:
            ''' parse json '''
            self.result = json.loads(popen_status[0])

            job_0 = self.result['jobs'][0]
            self.time_sec = float(job_0['elapsed'])
            self.bytes = int(job_0['write']['io_bytes'])
            self.xfer_speed = int(job_0['write']['bw_mean'])
            self.logger.debug("Result %.2f %d %d %s" % (self.time_sec, self.bytes, self.xfer_speed, self.xfer_unit))

        except ValueError:
            # popen_status[0] does not contain a json result, set to empty dict
            self.logger.error('Failed to parse stdout as json')
            self.result = None
            self.time_sec = 0
            self.bytes = 0
            self.xfer_speed = 0

    def get_datetime(self):
        # type: () -> str
        return str(self.datetime)

    def get_device(self):
        # type: () -> str
        return self.device

    def get_method(self):
        # type: () -> str
        return str(self.method)

    def get_bytes(self):
        # type: () -> int
        return self.bytes

    def get_rate(self):
        # type: () -> str
        return "%.1f %s" % (self.xfer_speed, self.xfer_unit)

    def __str__(self):
        return "Device: %s " % self.device + \
               "Bytes: %d " % self.bytes + \
               "Time: %s " % self.time_sec + \
               "Rate: %d %s" % (self.xfer_speed, self.xfer_unit)


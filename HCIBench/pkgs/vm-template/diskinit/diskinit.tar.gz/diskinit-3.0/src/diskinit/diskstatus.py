import datetime
import socket
import yaml
import netifaces as ni

from netifaces import AF_INET, AF_LINK
from pathlib2 import Path

from methods.result import Result


class DiskStatus(object):

    def __init__(self, path):
        # type: (Path) -> None
        self.path = path

        # Write header
        with self.path.open('w') as f:
            f.write(u"# Drive Initialization\n")

        dict_ = dict()
        dict_['hostname'] = socket.gethostname()
        dict_['datetime'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S:%f")

        list_ = list()
        for name in (x for x in ni.interfaces() if x.startswith('e')):

            interface = ni.ifaddresses(name)

            if AF_LINK in interface and len(interface[AF_LINK]) > 0:
                mac = interface[AF_LINK][0]['addr']
            else:
                mac = None

            if AF_INET in interface and len(interface[AF_INET]) > 0:
                ip = interface[AF_INET][0]['addr']
            else:
                ip = None
            list_.append({"interface": name, "mac": mac, "ip": ip})

        dict_['interfaces'] = list_

        with self.path.open('a') as f:
            yaml.safe_dump(dict_, f)
            f.write(u'devices:\n')

    def add(self, result):
        # type: (Result) -> None
        dict_ = dict()
        device = result.get_device()
        dict_[device] = dict()
        dict_[device]['datetime'] = result.get_datetime()
        dict_[device]['method'] = str(result.get_method())
        dict_[device]['bytes'] = result.get_bytes()
        dict_[device]['rate'] = result.get_rate()

        with self.path.open('a') as f:
            yaml.safe_dump([dict_], f)

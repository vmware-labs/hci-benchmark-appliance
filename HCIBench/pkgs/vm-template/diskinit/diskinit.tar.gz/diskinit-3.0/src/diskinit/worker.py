
import Queue
import logging
import threading


class Worker(threading.Thread):
    output_lock = threading.Lock()

    def __init__(self, tid, jobs, results):
        # type: (int, Queue.Queue, Queue.Queue) -> None
        threading.Thread.__init__(self)
        self.tid = tid
        self.jobs = jobs
        self.results = results
        self.shutdown_flag = threading.Event()

        ''' logger '''
        self.logger = logging.getLogger(__name__)
        self.logger.info("Created with tid %d" % self.tid)

    def run(self):
        # type: () -> None
        with self.output_lock:
            self.logger.info("Thread-%d Starting" % self.tid)

        while not self.shutdown_flag.is_set():

            # Get data
            data = self.jobs.get()
            if data is None:
                self.jobs.put(None)
                break

            # Print
            with self.output_lock:
                self.logger.info("Thread-%d: processing %s" % (self.tid, data))
                print("Thread-%d: processing %s" % (self.tid, data))

            # Process
            self.results.put(data.run())
            self.jobs.task_done()

        with self.output_lock:
            self.logger.info("Thread-%d Exiting" % self.tid)


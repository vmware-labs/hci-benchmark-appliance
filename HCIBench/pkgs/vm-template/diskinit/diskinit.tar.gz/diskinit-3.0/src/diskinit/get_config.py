from __future__ import print_function

import argparse
import sys

from pathlib2 import Path

from util import get_nb_processors
from diskinit.resources.ddflags import DDFlags
from diskinit.resources.initmethod import InitMethod
from methods.ddopenssldiskinit import DdOpensslDiskInit
from methods.ddrandomdiskinit import DdRandomDiskInit
from methods.ddzerodiskinit import DdZeroDiskInit
from methods.fiodiskinit import FioDiskInit


def get_config():
    # type: () -> dict

    parser = argparse.ArgumentParser(prog='PROG', usage='%(prog)s [options]')
    parser.add_argument('method', choices=[x for x in InitMethod.get_all_name()], type=str.lower, help='Method')
    parser.add_argument('--threads', type=int, help='Number of worker threads')
    parser.add_argument('--result', type=str, help='Result file ')
    parser.add_argument('--logfile', type=str, help='Log file')

    parser.add_argument('--dd-iflag', type=str, help='Set dd input flags')
    parser.add_argument('--dd-oflag', type=str, help='Set dd output flags')
    parser.add_argument('--dd-bs', type=int, help='Set dd block size (KB)')
    parser.add_argument('--dd-cache', action='store_true', help='Enable dd cache')

    parser.add_argument('--fio-iodepth', type=int, help='')
    parser.add_argument('--fio-bs', type=int, help='')

    args = parser.parse_args()

    config = dict()

    try:

        ''' Method '''
        if args.method == str(InitMethod.dd_zero):
            config['method'] = DdZeroDiskInit
            config['dd_bs'] = 65536
            config['dd_iflag'] = DDFlags.create_set('nocache')
            config['dd_oflag'] = DDFlags.create_set('nocache,dsync')

        elif args.method == str(InitMethod.dd_random):
            config['method'] = DdRandomDiskInit
            config['dd_bs'] = 65536
            config['dd_iflag'] = DDFlags.create_set('nocache')
            config['dd_oflag'] = DDFlags.create_set('nocache,dsync')

        elif args.method == str(InitMethod.dd_openssl):
            config['method'] = DdOpensslDiskInit
            config['dd_bs'] = 65536
            config['dd_iflag'] = DDFlags.create_set('nocache')
            config['dd_oflag'] = DDFlags.create_set('nocache,dsync')

        elif args.method == str(InitMethod.fio_zero):
            config['method'] = FioDiskInit
            config['fio_zero_buffers'] = True
            config['fio_bs'] = 65536
            config['fio_iodepth'] = 2

        elif args.method == str(InitMethod.fio_random):
            config['method'] = FioDiskInit
            config['fio_bs'] = 65536
            config['fio_iodepth'] = 2

        elif args.method == str(InitMethod.fio_random_dedupe):
            config['method'] = FioDiskInit
            config['fio_buffer_compress_percentage'] = 0
            config['fio_dedupe_percentage'] = 0
            config['fio_randrepeat'] = 0
            config['fio_bs'] = 65536
            config['fio_iodepth'] = 2

        else:
            raise ValueError('Invalid method: %s' % args.method)

        ''' Threads '''
        if args.threads is None:
            config['threads'] = get_nb_processors()
        else:
            config['threads'] = int(args.threads)

        ''' Result '''
        if args.result is None:
            config['result'] = Path('result.yml').resolve()
        else:
            config['result'] = Path(args.result).resolve()

        ''' Logfile '''
        if args.logfile is None:
            config['logfile'] = Path('diskinit.log').resolve()
        else:
            config['logfile'] = Path(args.logfile).resolve()

        ''' 
        DD Options 
        '''
        ''' DD Input Flags '''
        if args.dd_iflag is not None:
            if 'dd_iflag' not in config:
                config['dd_iflag'] = set()
            config['dd_iflag'].update(DDFlags.create_set(args.dd_iflag))

        ''' DD Output Flags '''
        if args.dd_oflag is not None:
            if 'dd_oflag' not in config:
                config['dd_oflag'] = set()
            config['dd_oflag'].update(DDFlags.create_set(args.dd_oflag))

        ''' DD Block Size '''
        if args.dd_bs is not None:
            config['dd_bs'] = int(args.dd_bs)

        ''' DD Cache '''
        if args.dd_cache:
            if 'dd_iflag' in config:
                if DDFlags.nocache in config['dd_iflag']:
                    config['dd_iflag'].remove(DDFlags.nocache)
            if 'dd_oflag' in config:
                if DDFlags.nocache in config['dd_oflag']:
                    config['dd_oflag'].remove(DDFlags.nocache)
                if DDFlags.dsync in config['dd_oflag']:
                    config['dd_oflag'].remove(DDFlags.dsync)

        '''
        FIO Options
        '''
        ''' iodepth '''
        if args.fio_iodepth is not None:
            config['fio_iodepth'] = int(args.fio_iodepth)

        ''' bs '''
        if args.fio_bs is not None:
            config['fio_bs'] = int(args.fio_bs)

    except Exception as e:
        print('Error while parsing arguments: %s' % e, file=sys.stderr)
        exit(1)

    return config

Multithreaded disk initializtion tool.

``` bash
disk_init_tester --help
usage: PROG [options]

positional arguments:
  {fio,openssl,random,zero}
                        method to test

optional arguments:
  -h, --help            show this help message and exit
  --threads THREADS     number of threads to test
  --logfile LOGFILE     logfile
```

* finds any scsi devices with no partition. E.g. In the following device list sdb-sdg would be initialized, sda would not be affected.
``` bash
ls -l /dev/sd*
brw-rw---- 1 root disk 8,  0 Apr 21 23:22 /dev/sda
brw-rw---- 1 root disk 8,  1 Apr 21 23:22 /dev/sda1
brw-rw---- 1 root disk 8,  2 Apr 21 23:22 /dev/sda2
brw-rw---- 1 root disk 8, 16 Apr 22 16:11 /dev/sdb
brw-rw---- 1 root disk 8, 32 Apr 22 16:11 /dev/sdc
brw-rw---- 1 root disk 8, 48 Apr 22 16:11 /dev/sdd
brw-rw---- 1 root disk 8, 64 Apr 22 16:11 /dev/sde
brw-rw---- 1 root disk 8, 80 Apr 22 16:10 /dev/sdf
brw-rw---- 1 root disk 8, 96 Apr 22 16:10 /dev/sdg
```

* initialized the disks using different methods fio,openssl,random,zero
  * zero: ```dd if='/dev/zero' of='/dev/sdx'```
  * random: ```dd if='/dev/urandome' of='/dev/sdx'```
  * openssl: ```openssl | dd of='/dev/sdx'```
  * fio: ```fio -rw write /dev/sdx```

* supports concurent operation via threads
  * default: detect the number of cpu and use 1 thread per cpu
  * specify: via the ```--threads n``` option

* logs results 
  * default: ```disk_init_timer.log```
  * speci ofy: via the ```--logfile <file>``` option
import inspect

from enum import Enum
from typeguard import typechecked
from typing import List


class FioContinueOnError(Enum):
    """ FIO Continue On Error
        Desc:   Normally fio will exit the job on the first observed failure.
                If this option is set, fio will continue the job when there is a ‘non-fatal error’ (EIO or EILSEQ) until
                the runtime is exceeded or the I/O size specified is completed. If this option is used, there are two
                more stats that are appended, the total error count and the first error. The error field given in the
                stats is the first error that was hit during the run.
        Values: - none: Exit on any I/O or verify errors.
                - read: Continue on read errors, exit on all others.
                - write: Continue on write errors, exit on all others.
                - io: Continue on any I/O error, exit on all others.
                - verify: Continue on verify errors, exit on all others.
                - all: Continue on all errors.
                - 0: Backward-compatible alias for ‘none’.
                - 1: Backward-compatible alias for ‘all’.
        Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#error-handling
        """
    none = 0
    read = 1
    write = 2
    io = 3
    verify = 4
    all = 5

    @classmethod
    @typechecked
    def create(cls, name: str) -> 'FioContinueOnError':
        for item in cls:
            if item.name == name:
                return item

        # Backward compatibility for 0
        if name == '0':
            return FioContinueOnError.none

        # Backward compatibility for 1
        if name == '1':
            return FioContinueOnError.all

        raise ValueError('Enumeration FioContinueOnError',
                         'Method %s' % inspect.getframeinfo(inspect.currentframe()).function,
                         'Input does not match a known type',
                         'Received {name}')

    @classmethod
    @typechecked
    def has_name(cls, name: str) -> bool:
        return any(name == item.name for item in cls)

    @classmethod
    @typechecked
    def has_value(cls, value: int) -> bool:
        return any(value == item.value for item in cls)

    @classmethod
    @typechecked
    def get_all_member(cls) -> List['FioContinueOnError']:
        return [item for item in cls]

    @classmethod
    @typechecked
    def get_all_name(cls) -> List[str]:
        return [item.name for item in cls]

    @classmethod
    @typechecked
    def get_all_value(cls) -> List[int]:
        return [item.value for item in cls]

    def __str__(self) -> str:
        switch = {
            FioContinueOnError.none.value: 'none',
            FioContinueOnError.read.value: 'read',
            FioContinueOnError.write.value: 'write',
            FioContinueOnError.io.value: 'io',
            FioContinueOnError.verify.value: 'verify',
            FioContinueOnError.all.value: 'all',
        }
        return switch.get(self.value)

    def __repr__(self):
        return self.__str__()

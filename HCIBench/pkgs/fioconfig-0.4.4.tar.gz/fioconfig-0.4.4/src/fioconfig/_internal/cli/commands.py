import ast

from pathlib import Path
from sys import exit

import click

from fioconfig.__about__ import __version__
from fioconfig.fioconfig import FioConfig


@click.group()
@click.version_option(version=__version__)
def cli():
    pass


class PythonLiteralOption2(click.Option):
    def type_cast_value(self, ctx, value):

        if value is None:
            return

        values = value.split(",")

        if len(values) < 1:
            raise click.BadParameter("Too few values.")

        if len(values) > 3:
            raise click.BadParameter("Too many values: %s (max 3: read, write, trim)." % value)

        try:
            result = [(None if len(x) < 1 else ast.literal_eval(x)) for x in values]
        except Exception:
            raise click.BadParameter(value)

        if len([x for x in result if x is not None]) > 0:
            return result

        raise click.BadParameter(value)

# if isinstance(values, str):
#    result = re.search(r"(\d*)(?:,(\d*))(?:,(\d*))", values)
#    print(result)


# https://stackoverflow.com/questions/47631914/how-to-pass-several-list-of-arguments-to-click-option
class PythonLiteralOption(click.Option):
    def type_cast_value(self, ctx, value):
        try:
            values = ast.literal_eval(value)
        except Exception:
            raise click.BadParameter(value)

        if isinstance(values, int):
            if values < 1:
                raise click.BadParameter("Value %s not valid." % values)
            return [values, ]

        if isinstance(values, tuple):
            if len(values) > 3:
                raise click.BadParameter("Too many values: %s (max 3: read, write, trim)." % value)

            for x in values:
                if x < 1:
                    raise click.BadParameter("Value %s in %s is not valid." % (x, value))
            return list(values)

        raise click.BadParameter(value)


@cli.command('create')
@click.option('-b', 'block_size', type=str, required=True, help='Block size')
@click.option('-e', 'testing_time', type=click.IntRange(min=1), required=True, help='Testing time (seconds)')
@click.option('-n', 'nb_disks', type=click.IntRange(min=1, max=60), required=True, help='Number of data disks')
@click.option('-r', 'read_pct', type=click.IntRange(min=0, max=100), required=True, help='Read percentage')
@click.option('-s', 'random_pct', type=click.IntRange(min=0, max=100), required=True, help='Random percentage')
@click.option('-w', 'working_set', type=click.IntRange(min=1, max=100), required=True, help='Working set percentage')
@click.option('-m', 'warmup_time', type=click.IntRange(min=1), help='Warmup time (seconds)')
@click.option('-o', 'io_rate', cls=PythonLiteralOption2, help='IO Rate')
@click.option('-p', 'profile_prefix', type=click.STRING, help='Profile prefix')
@click.option('-t', 'nb_threads', type=click.IntRange(min=1), default=1, help='Number of threads per data disk')
@click.option('-j', 'nb_jobs', type=click.IntRange(min=1, max=64), required=False, help='Number of jobs')
@click.option('-c', 'cpu_load', type=click.IntRange(min=1, max=100), help='CPU utilization percentage')
@click.option('-nc', 'nb_cpu', type=click.IntRange(min=1), help='Number of CPU to run')
@click.option('-lt', 'latency_target', type=click.IntRange(min=1), help='Latency target in microseconds')
@click.option('-bc', 'buffer_compress_pct', type=click.IntRange(min=0, max=100), required=False, help='Buffer compress percentage')
@click.option('-dp', 'dedupe_pct', type=click.IntRange(min=0, max=100), required=False, help='Dedupe percentage')
@click.option('-d', 'output_directory',
              type=click.Path(exists=True, file_okay=False, resolve_path=True),
              default=".", help='Output directory')
@click.option('-N', 'nvme_ctrlr', is_flag=True, show_default=True, default=False, help='specify when need to create fio param file based on vNVMe controller')

def create(block_size: str,
           testing_time: int,
           nb_disks: int,
           read_pct: int,
           random_pct: int,
           working_set: int,
           warmup_time: int,
           io_rate: int,
           profile_prefix: str,
           nb_threads: int,
           nb_jobs: int,
           cpu_load: int,
           nb_cpu: int,
           latency_target: int,
           buffer_compress_pct: int,
           dedupe_pct: int,
           output_directory: str,
           nvme_ctrlr: bool):
    header = '; Auto generated FIO parameter file\n' + \
             '; block_size:          ' + str(block_size) + '\n' + \
             '; testing_time:        ' + str(testing_time) + ' \n' + \
             '; warmup_time:         ' + str(warmup_time) + '\n' + \
             '; nb_disks:            ' + str(nb_disks) + '\n' + \
             '; io_rate:             ' + str(io_rate) + '\n' + \
             '; read_pct:            ' + str(read_pct) + '\n' + \
             '; random_pct:          ' + str(random_pct) + '\n' + \
             '; working_set:         ' + str(working_set) + '\n' + \
             '; nvme_ctrlr:          ' + str(nvme_ctrlr) + '\n'

    if latency_target is not None:
        params = (nb_disks, working_set, block_size, read_pct, random_pct, latency_target)
        output_file = 'fio-%dvmdk-%dws-%s-%drdpct-%drandompct-%dlt' % params
    else:
        params = (nb_disks, working_set, block_size, read_pct, random_pct, nb_threads)
        output_file = 'fio-%dvmdk-%dws-%s-%drdpct-%drandompct-%dthreads' % params

    if profile_prefix:
        output_file = '%s-%s' % (profile_prefix, output_file)

    # Add folder
    output_file = Path(output_directory) / output_file

    if nb_jobs is not None:
        output_file = Path(str(output_file) + '-%djobs' % nb_jobs)
        header += '; nb_jobs:             ' + str(nb_jobs)

        if nb_jobs > nb_disks:
            header += ' - Warning: There were more jobs specified than disks\n'
        else:
            header += '\n'

    if not (cpu_load is None) and not (nb_cpu is None):
        output_file = Path(str(output_file) + '-%dcpu-%dcpupct' % (nb_cpu, cpu_load))
        header += '; nb_cpus:             ' + str(nb_cpu) + '\n' + \
                  '; cpuio:               ' + str(cpu_load) + '\n'

    if latency_target is not None:
        latency_window = 1000000    # increase OIO every 1sec
        latency_percentile = 95.0   # 95% tile
        latency_run = 1             # keep going until runtime exceeds
        nb_threads = 1024           # set the max threads to 1024
        header += '; latency_target:      ' + str(latency_target) + '\n' + \
                  '; latency_window:      ' + str(latency_window) + '\n' + \
                  '; latency_percentile:  ' + str(latency_percentile) + ' \n' + \
                  '; latency_run:         ' + str(latency_run) + '\n' + \
                  '; nb_threads:          ' + str(nb_threads) + ' # override by latency_target\n'
    else:
        latency_window = None
        latency_percentile = None
        latency_run = None
        header += '; nb_threads:          ' + str(nb_threads) + '\n'

    if buffer_compress_pct is not None:
        output_file = Path(str(output_file) + '-%dcompress' % buffer_compress_pct)
        header += '; buffer_compress_pct: ' + str(buffer_compress_pct) + '\n'

    if dedupe_pct is not None:
        output_file = Path(str(output_file) + '-%ddedupe' % dedupe_pct)
        header += '; dedupe_pct:          ' + str(dedupe_pct) + '\n'


    try:
        FioConfig(block_size=block_size,
                  testing_time=testing_time,
                  nb_disks=nb_disks,
                  read_percentage=read_pct,
                  seek_percentage=random_pct,
                  working_set=working_set,
                  warmup_time=warmup_time,
                  io_rate=io_rate,
                  nb_threads=nb_threads,
                  nb_jobs=nb_jobs,
                  cpu_load=cpu_load,
                  nb_cpu=nb_cpu,
                  latency_target=latency_target,
                  latency_window=latency_window,
                  latency_percentile=latency_percentile,
                  latency_run=latency_run,
                  buffer_compress_percentage=buffer_compress_pct,
                  dedupe_percentage=dedupe_pct,
                  nvme_ctrlr=nvme_ctrlr
                  ).write(output_file, header)

    except ValueError as e:
        click.echo('error: invalid value: %s' % str(e), err=True)
        exit(1)

    except Exception as e:
        click.echo('error: %s' % str(e), err=True)
        exit(1)

    else:
        click.echo('Output file: %s' % output_file)

import inspect

from typeguard import typechecked
from typing import List
from typing import Union


class FioRateIops(object):

    def __init__(self, value: List[int]):
        self.rate_iops = value

    #
    # Properties
    #

    # rate_iops
    @property
    def rate_iops(self) -> List[int]:
        return self._rate_iops

    @rate_iops.setter
    @typechecked()
    def rate_iops(self, value: List[Union[None, int]]):

        if len([x for x in value if not ((x is None) or isinstance(x, int))]) > 0:
            raise ValueError('Class FioRateIops ' +
                             'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                             'Input contains invalid types. ' +
                             'Received: %s' % value)

        if len([x for x in value if (x is not None) and (x < 1)]) > 0:
            raise ValueError('Class FioRateIops ' +
                             'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                             'Input is out of range ' +
                             'Expected range: > 1 ' +
                             'Received: %s' % value)

        if len([x for x in value if x is not None]) == 0:
            raise ValueError('Class FioRateIops ' +
                             'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                             'Input is not valid. ' +
                             'Received: %s' % value)

        self._rate_iops = value

    #
    # Builtin
    #
    def __str__(self) -> str:
        return ",".join([('' if x is None else str(x)) for x in self._rate_iops])

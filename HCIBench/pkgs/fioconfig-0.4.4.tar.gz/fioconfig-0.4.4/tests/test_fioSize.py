import inspect
import string

import numpy as np
import threading
from unittest import TestCase

from fioconfig.fiosize import FioSize
from fioconfig.fiosizeunit import FioSizeUnit

NB_SAMPLES = 100
INT_INV_MIN = -10000
INT_INV_MAX = 0
INT_MIN = 1
INT_MAX = 10000


class TestFioSize(TestCase):

    test_results = list()
    test_results_lock = threading.Lock()
    classname = None

    @classmethod
    def setUpClass(cls):
        size_valid = [1] + [int(value) for value in np.random.randint(INT_MIN, INT_MAX, size=(NB_SAMPLES,))]
        size_invalid = [0] + [int(value) for value in np.random.randint(INT_INV_MIN, INT_INV_MAX, size=(NB_SAMPLES,))]
        unit_valid = [x.lower().capitalize() for x in FioSizeUnit.get_all_name()] + \
                     [x.lower() for x in FioSizeUnit.get_all_name()] + \
                     [x.upper() for x in FioSizeUnit.get_all_name()]
        unit_invalid = [x for x in [''.join(np.random.choice(list(string.ascii_letters)) for _ in
                                            range(np.random.randint(1, 4))) for _ in
                                    range(NB_SAMPLES)] if x not in unit_valid]

        cls.valid = list()
        for size in size_valid:
            for unit in unit_valid:
                if unit in ['percent', 'Percent', 'PERCENT', '%'] and size > 100:
                    continue
                cls.valid.append('%s%s' % (size, unit))

        cls.invalid = list()
        for size in size_invalid:
            for unit in unit_invalid:
                cls.invalid.append('%s%s' % (size, unit))

        cls.classname = cls().__class__.__name__

    @classmethod
    def tearDownClass(cls):
        total = int(0)
        test_summary = ''

        cls.test_results_lock.acquire()
        for fname, count in cls.test_results:
            test_summary += 'Method %s.%s: %d tests\n' % (cls.classname, fname, count)
            total += count
        cls.test_results_lock.release()

        print('{test_summary}Class %s total: %d tests' % (cls.classname, total))

    @classmethod
    def add_result(cls, fname, count):
        cls.test_results_lock.acquire()
        cls.test_results.append((fname, count))
        cls.test_results_lock.release()

    def setUp(self):
        self.count = int(0)

    def tearDown(self):
        # Make sure we tested something, otherwise add tests count
        self.assertTrue(self.count > 0, msg='Method %s had 0 tests cases' % self.fname)
        self.add_result(self.fname, self.count)

    #
    # Tests
    #
    def test___init__(self):
        self.fname = inspect.getframeinfo(inspect.currentframe()).function

        for item in self.valid:
            self.assertTrue(FioSize(item), msg='Method %s Returned None' % self.fname)
            self.count += 1

        for item in self.invalid:
            with self.assertRaises(ValueError,
                                   msg='Method %s Input: %s failed to raise exception' % (self.fname, item)):
                self.count += 1
                FioSize(item)

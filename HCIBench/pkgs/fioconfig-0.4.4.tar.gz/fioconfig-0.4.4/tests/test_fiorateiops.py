import ast
from unittest import TestCase

from fioconfig.fiorateiops import FioRateIops


class TestFioRateIops(TestCase):

    def test_001(self):
        for x in ["1", "10", "1000", "10000"]:
            self.assertTrue(str(FioRateIops([int(x) for x in x.split(",")])) == str(x))

    def test_002(self):
        for x in ["-100", "-1", "0"]:
            with self.assertRaises(ValueError):
                FioRateIops([int(x) for x in x.split(",")])

    def test_003(self):
        with self.assertRaises(ValueError):
            FioRateIops([None])

    def test_004(self):
        for x in ["a", "cat", "-100.0", "-1.0", "1.1", "100.3"]:
            with self.assertRaises(TypeError):
                FioRateIops([x for x in x.split(",")])

    def test_005(self):
        for x in ["100,", ",100", "100,,", "100,100,", "100,,100", ",100,100", ",,100"]:
            self.assertTrue(str(FioRateIops([(None if len(y) < 1 else ast.literal_eval(y)) for y in x.split(",")])) == x)

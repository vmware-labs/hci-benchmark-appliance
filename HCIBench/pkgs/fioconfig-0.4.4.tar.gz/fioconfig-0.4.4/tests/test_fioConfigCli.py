
import re

from click.testing import CliRunner
from unittest import TestCase

from fioconfig._internal.cli.commands import cli


class TestFioConfig(TestCase):

    def test_001(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(cli)
            assert result.exit_code == 0
            assert re.search(r'^Usage: \w+ \[OPTIONS\] COMMAND \[ARGS\]\.{3}', result.output)


